const DEBUG_MODE = false;
if (!DEBUG_MODE) { console.log = () => { }; console.warn = () => { }; console.error = () => { }; }

// GRACELY AUTH SYNC (Mobile & Incognito Compatibility)
// Menarik JWT murni dari web dan melemparnya ke Ekstensi untuk disimpan di secureStorage lokal.
if (window.location.hostname.includes('gracely011.github.io') || window.location.hostname.includes('petrussiahaan.blogspot.com')) {
    let lastKnownToken = undefined;

    function checkAndSyncToken() {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; gracely_session_token=`);
        let currentToken = null;
        
        if (parts.length === 2) {
            currentToken = parts.pop().split(';').shift();
        }

        if (currentToken !== lastKnownToken) {
            lastKnownToken = currentToken;
            try {
                if (currentToken) {
                    chrome.runtime.sendMessage({ action: "syncMobileToken", token: currentToken }, () => {
                        if (chrome.runtime.lastError) {} // Ignore
                    });
                } else {
                    chrome.runtime.sendMessage({ action: "logout" }, () => {
                        if (chrome.runtime.lastError) {} // Ignore
                    });
                }
            } catch (e) {}
        }
    }
    checkAndSyncToken();
    setInterval(checkAndSyncToken, 2000); // Sinkronisasi proaktif setiap 2 detik
}
const isGracelySessionActive = document.cookie.includes('gracely_active_session=true');
if (isGracelySessionActive) {
    let BLOCKED_URL = 'https://gracely011.github.io/hai/blocked.html'; let PROFILE_ICON_URL = 'https://gracely011.github.io/hai/assets/halo/halooo.png'; const SITE_SELECTORS = { 'chatgpt.com': ['a[href*="/auth/logout"]', 'button[data-testid="logout-button"]'], 'netflix.com': ['a[href*="/SignOut"]', 'a[aria-label="Sign out"]'], 'canva.com': ['button[role="menuitem"]:last-child', 'div[data-cy="logout-button"]', 'button:contains("Log out")'], 'masterclass.com': ['a[href*="/logout"]'], 'primevideo.com': ['a[data-testid="pv-nav-sign-out"]'], 'perplexity.ai': ['a[href*="/sign-out"]'], 'academia.edu': ['a[href*="/logout"]'], 'scribd.com': ['a[href*="/logout"]', 'button[data-e2e*="logout"]'] }; const HEURISTIC_KEYWORDS = ['logout', 'signout', 'sign-out', 'exit', 'logoff', 'keluar', 'salir', 'déconnexion', 'abmelden', 'sair']; const RANDOM_HASHTAGS = ['i-love-gracely', 'i-like-gracely', 'no-gracely-no-love', 'horas-lae-ito', 'tarito', 'gracely', 'halak-hita']; function replaceUrlHash() { const currentHash = window.location.hash.substring(1); if (!RANDOM_HASHTAGS.includes(currentHash)) { const randomIndex = Math.floor(Math.random() * RANDOM_HASHTAGS.length); const newHash = RANDOM_HASHTAGS[randomIndex]; window.location.hash = newHash; } }
    async function fetchConfig() { try { const CONFIG_URL = 'https://gracely011.github.io/hai/aturhonma.js'; const response = await fetch(CONFIG_URL, { cache: 'no-cache' }); if (!response.ok) return; const text = await response.text(); const jsonText = text.replace('const gracelyConfig =', '').trim().replace(/;$/, ''); const config = JSON.parse(jsonText); if (config.urls) { if (config.urls.profileIcon) PROFILE_ICON_URL = config.urls.profileIcon; if (config.urls.onLogoutBlock) BLOCKED_URL = config.urls.onLogoutBlock; } } catch (error) { console.warn('[Gracely Guard] Gagal mengambil konfigurasi.', error); } }
    // --- OPTIMIZED TEXT REPLACEMENT ---
    function processTextNode(node) {
        const searchRegex = /groupy/gi;
        const replacer = (match) => {
            if (match === 'groupy') return 'gracely';
            if (match === 'grouuuupy') return 'graceeeely';
            if (match === 'Groupy') return 'Gracely';
            if (match === 'GROUPY') return 'GRACELY';
            return 'Gracely';
        };
        if (searchRegex.test(node.nodeValue)) {
            node.nodeValue = node.nodeValue.replace(searchRegex, replacer);
        }
    }

    function modifyGroupyToGracely(targetNode = document.body) {
        const walker = document.createTreeWalker(targetNode, NodeFilter.SHOW_TEXT, null, false);
        let node;
        while (node = walker.nextNode()) {
            const parentTag = node.parentElement ? node.parentElement.tagName : '';
            if (parentTag !== 'SCRIPT' && parentTag !== 'STYLE' && parentTag !== 'NOSCRIPT') {
                processTextNode(node);
            }
        }
    }
    // ----------------------------------

    function modifyMedium() { if (window.location.hostname.includes('medium.com')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely Pro"; const profileImages = document.querySelectorAll('img[alt="Groupy Pro"]'); profileImages.forEach(img => { if (img.src !== newIconUrl) img.src = newIconUrl; if (img.alt !== newName) img.alt = newName; if (img.hasAttribute('srcset')) img.removeAttribute('srcset'); Object.assign(img.style, { objectFit: 'cover' }); }); } }
    function modifyNetflixProfileIcons() { if (window.location.hostname.includes('netflix.com')) { const newIconUrl = PROFILE_ICON_URL; document.querySelectorAll('div.profile-icon').forEach(icon => { icon.style.backgroundColor = '#000000'; icon.style.backgroundImage = `url(${newIconUrl})`; icon.style.backgroundSize = 'contain'; icon.style.backgroundRepeat = 'no-repeat'; icon.style.backgroundPosition = 'center'; }); document.querySelectorAll('img.profile-icon').forEach(icon => { if (icon.src !== newIconUrl) icon.src = newIconUrl; }); } }
    function modifyMasterClassProfileIcons() { if (window.location.hostname.includes('masterclass.com')) { const newIconUrl = PROFILE_ICON_URL; document.querySelectorAll('img.ProfileAvatar-module__avatar--kUmfr').forEach(icon => { if (icon.src !== newIconUrl) icon.src = newIconUrl; }); } }
    function modifyPrimeVideoProfileIcons() { if (window.location.hostname.includes('primevideo.com')) { const newIconUrl = PROFILE_ICON_URL; document.querySelectorAll('span.Me4\\+tP').forEach(icon => { icon.style.setProperty('--profile-avatar', `url('${newIconUrl}')`); }); } }
    function applyChatGptStyleOverride() { if (window.location.hostname.includes('chatgpt.com')) { const styleId = 'gracely-chatgpt-override'; if (document.getElementById(styleId)) return; const newIconUrl = PROFILE_ICON_URL; const cssRules = ` div[data-testid="accounts-profile-button"] div.rounded-full > * { background-image: url('${newIconUrl}') !important; background-size: cover !important; background-position: center !important; } div[data-testid="accounts-profile-button"] div.rounded-full img { opacity: 0 !important; } div[data-testid="accounts-profile-button"] div.text-xs { opacity: 0 !important; }`; const styleElement = document.createElement('style'); styleElement.id = styleId; styleElement.textContent = cssRules; document.head.appendChild(styleElement); } }
    function modifyPerplexityProfileIcons() { if (window.location.hostname.includes('perplexity.ai')) { const newIconUrl = PROFILE_ICON_URL; document.querySelectorAll('img.size-full.object-cover.rounded-full').forEach(profileImg => { if (profileImg && profileImg.src !== newIconUrl) profileImg.src = newIconUrl; }); } }
    function modifyAcademiaProfileIcons() { if (window.location.hostname.includes('academia.edu')) { const newIconUrl = PROFILE_ICON_URL; const selectors = ['div[class*="ActionNav-cls"] a[aria-label*="profile"] img', 'button[class*="AccountMenuButton-"] img', 'a[class*="AccountMenu-"] img', 'img.profile-avatar', 'div[class*="PostPrompt-cls"] img[class*="Avatar-cls"]']; document.querySelectorAll(selectors.join(', ')).forEach(element => { if (element && element.src !== newIconUrl) { element.src = newIconUrl; } }); } }
    function modifyAcademiaAccountNames() { if (window.location.hostname.includes('academia.edu')) { const newNamePro = "Gracely Pro", newName = "Gracely"; const nameUpdates = { 'p[class*="ActionNav-cls"][class*="body-md-bold"]': newNamePro, 'div[class*="AccountMenuButton-"] > a[class*="AccountMenu-"] > div': newNamePro, 'button[class*="AccountMenuButton-"] > div[class*="AccountMenuButton-"]': newName }; Object.entries(nameUpdates).forEach(([selector, name]) => { const element = document.querySelector(selector); if (element && element.textContent !== name) element.textContent = name; }); const profilePageName = document.querySelector('h1'); if (profilePageName && profilePageName.textContent.trim() === 'Groupy Pro') profilePageName.textContent = newNamePro; const profilePageAvatar = document.querySelector('img.profile-avatar'); if (profilePageAvatar && profilePageAvatar.alt !== `Photo of ${newNamePro}`) profilePageAvatar.alt = `Photo of ${newNamePro}`; } }
    function modifyScribdProfileIcon() { if (window.location.hostname.includes('scribd.com')) { const newIconUrl = PROFILE_ICON_URL; const avatarContainer = document.querySelector('button[data-e2e="megamenu-top-bar-user-menu-button"] div[class*="CoreAvatar-module_wrapper"]'); if (avatarContainer && !avatarContainer.querySelector('img.gracely-avatar')) { avatarContainer.innerHTML = ''; const gracelyImg = Object.assign(document.createElement('img'), { src: newIconUrl, className: 'gracely-avatar', style: 'width:100%; height:100%; object-fit:cover; border-radius:50%;' }); avatarContainer.appendChild(gracelyImg); } } }
    function modifyCrunchyrollProfileIcons() { if (window.location.hostname.includes('crunchyroll.com')) { const newIconUrl = PROFILE_ICON_URL; document.querySelectorAll('img[alt="Profile Avatar"], img[alt="User Avatar"]').forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; if (img.hasAttribute('srcset')) img.removeAttribute('srcset'); } }); } }
    function modifyILoveSites() { if (window.location.hostname.includes('iloveimg.com') || window.location.hostname.includes('ilovepdf.com')) { const newIconUrl = PROFILE_ICON_URL, newName = "Gracely", newEmail = "premium@gracely.com"; document.querySelectorAll('img.avatar.avatar--desktop').forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; Object.assign(img.style, { width: '200%', height: '200%', objectFit: 'cover', borderRadius: '50%' }); } if (img.alt !== newName) img.alt = newName; }); const nameElement = document.querySelector('.user-item .navbar__item__title'); if (nameElement && !nameElement.textContent.includes(newName)) nameElement.firstChild.nodeValue = newName + ' '; const emailElement = document.querySelector('.user-item .navbar__item__description'); if (emailElement && emailElement.textContent !== newEmail) emailElement.textContent = newEmail; const userLink = document.querySelector('.user-item > a'); if (userLink && userLink.title !== newName) userLink.title = newName; } }
    function modifyMubiProfilePictures() { if (window.location.hostname.includes('mubi.com')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely Pro"; document.querySelectorAll('img.css-1df1eln.e1ak10vj2').forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; img.alt = newName + "'s profile picture"; if (img.hasAttribute('srcset')) img.removeAttribute('srcset'); Object.assign(img.style, { objectFit: 'cover' }); } }); document.querySelectorAll('picture.css-4yxxwq.e1f0a7wz0').forEach(pictureElement => { pictureElement.querySelectorAll('source').forEach(source => { source.srcset = newIconUrl; }); const fallbackImg = pictureElement.querySelector('img.css-12ol5ic.e1f0a7wz1'); if (fallbackImg && fallbackImg.src !== newIconUrl) { fallbackImg.src = newIconUrl; fallbackImg.alt = newName + "'s profile picture"; if (fallbackImg.hasAttribute('srcset')) fallbackImg.removeAttribute('srcset'); } }); } }
    function modifyAskYourPdf() { if (window.location.hostname.includes('askyourpdf.com')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely Premium"; const profileImage = document.querySelector('img.h-32.w-32.rounded-full'); if (profileImage && profileImage.src !== newIconUrl) { profileImage.src = newIconUrl; profileImage.style.objectFit = 'cover'; } const nameElement = document.querySelector('p.text-captionL.font-medium.capitalize'); if (nameElement && nameElement.textContent !== newName) { nameElement.textContent = newName; } } }
    function modifyBilibili() { if (window.location.hostname.includes('bilibili.tv')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely Premium"; const profileImages = document.querySelectorAll('.bstar-header-avatar img'); profileImages.forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; img.alt = newName; Object.assign(img.style, { objectFit: 'cover', borderRadius: '50%' }); } }); const nameElement = document.querySelector('.bstar-header-user-content__name'); if (nameElement && nameElement.textContent !== newName) { nameElement.textContent = newName; } } }
    function modifySlideshare() { if (window.location.hostname.includes('slideshare.net')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely Pro"; const profileImage = document.querySelector('div[data-cy="user-bubble"] img'); if (profileImage) { if (profileImage.src !== newIconUrl) { profileImage.src = newIconUrl; profileImage.style.objectFit = 'cover'; } if (profileImage.alt !== newName + ", profile picture") { profileImage.alt = newName + ", profile picture"; } } } }
    function modifyMusicbedProfileIcon() { if (window.location.hostname.includes('musicbed.com')) { const styleId = 'gracely-musicbed-override'; const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely"; const newEmail = "premium@gracely.com"; if (document.getElementById(styleId)) { const dropdownContainer = document.querySelector('div[data-cy="_Header_HStack"]'); if (dropdownContainer) { const usernameP = dropdownContainer.querySelector('p[data-cy="_Header_Text"]'); const emailP = Array.from(dropdownContainer.querySelectorAll('p')).find(p => p.textContent.includes('@')); if (usernameP && usernameP.textContent !== newName) usernameP.textContent = newName; if (emailP && emailP.textContent !== newEmail) emailP.textContent = newEmail; } return; } const cssRules = ` div[data-cy="_Header_Box"] { background-image: url("${newIconUrl}") !important; } `; const styleElement = document.createElement('style'); styleElement.id = styleId; styleElement.textContent = cssRules; document.head.appendChild(styleElement); const observer = new MutationObserver((mutationsList, obs) => { const dropdownContainer = document.querySelector('div[data-cy="_Header_HStack"]'); if (dropdownContainer) { const dropdownImg = dropdownContainer.querySelector('img'); const usernameP = dropdownContainer.querySelector('p[data-cy="_Header_Text"]'); const emailP = Array.from(dropdownContainer.querySelectorAll('p')).find(p => p.textContent.includes('@')); if (dropdownImg) dropdownImg.src = newIconUrl; if (usernameP) usernameP.textContent = newName; if (emailP) emailP.textContent = newEmail; obs.disconnect(); } }); observer.observe(document.body, { childList: true, subtree: true }); } }
    function modifyQuizletProfileIcon() { if (window.location.hostname.includes('quizlet.com')) { const newIconUrl = PROFILE_ICON_URL; document.querySelectorAll('img.AssemblyAvatar').forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; } if (img.style.backgroundImage !== 'none') { img.style.backgroundImage = 'none'; } if (img.hasAttribute('srcset')) { img.removeAttribute('srcset'); } Object.assign(img.style, { objectFit: 'cover' }); }); } }
    function modifyBusuuProfileIcon() { if (window.location.hostname.includes('busuu.com')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely"; const selectors = ['[data-cy="MyProfile__profileIcon"] img', 'img.profile-info__picture']; document.querySelectorAll(selectors.join(', ')).forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; } if (img.alt.toLowerCase().includes('groupy')) { img.alt = newName; } if (img.hasAttribute('srcset')) { img.removeAttribute('srcset'); } Object.assign(img.style, { objectFit: 'cover', borderRadius: '50%' }); }); } }
    function modifyEverandProfileIcon() { if (window.location.hostname.includes('everand.com')) { const newIconUrl = PROFILE_ICON_URL; const profileImages = document.querySelectorAll('img.PersonaIcon-module_userProfilePicture__paNzD'); profileImages.forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; } if (img.hasAttribute('srcset')) { img.removeAttribute('srcset'); } Object.assign(img.style, { objectFit: 'cover' }); }); } }
    function modifySvgatorProfileIcon() { if (window.location.hostname.includes('svgator.com')) { const newIconUrl = PROFILE_ICON_URL; document.querySelectorAll('div.avatar-image').forEach(div => { const newStyle = `url("${newIconUrl}")`; if (div.style.backgroundImage !== newStyle) { div.style.backgroundImage = newStyle; } }); } }
    function modifySpeechifyProfileIcon() { if (window.location.hostname.includes('speechify.com')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely"; const profileImages = document.querySelectorAll('img.rounded-full.object-cover'); profileImages.forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; } if (img.alt !== newName && img.alt !== "Profile Avatar") { img.alt = newName; } if (img.hasAttribute('srcset')) { img.removeAttribute('srcset'); } }); } }
    function modifyDeeplLogo() { if (window.location.hostname.includes('deepl.com')) { const newIconUrl = PROFILE_ICON_URL; document.querySelectorAll('img[data-testid="header-logo-image"]').forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; Object.assign(img.style, { objectFit: 'cover' }); } }); } }
    function modifyRawpixelProfile() { if (window.location.hostname.includes('rawpixel.com')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely Premium"; const avatarSelectors = ['div.avatar-thumb', 'div.thumb-wrapper.image-avatar']; document.querySelectorAll(avatarSelectors.join(', ')).forEach(div => { const newStyle = `url("${newIconUrl}")`; if (div.style.backgroundImage !== newStyle) { div.style.backgroundImage = newStyle; } }); const nameElement = document.querySelector('div.user-fullname'); if (nameElement && nameElement.textContent !== newName) { nameElement.textContent = newName; } } }
    function modifyEducativeProfile() { if (window.location.hostname.includes('educative.io')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely Pro"; const newWelcomeMessage = ", Gracely!"; document.querySelectorAll('img[title="Groupy Pro"]').forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; img.title = newName; img.alt = newName; if (img.hasAttribute('srcset')) { img.removeAttribute('srcset'); } Object.assign(img.style, { objectFit: 'cover', borderRadius: '50%' }); } }); const welcomeNameElement = document.querySelector('p.WelcomeMessage_heading__vUEw_'); if (welcomeNameElement && welcomeNameElement.textContent.includes(', Groupy!')) { welcomeNameElement.textContent = welcomeNameElement.textContent.replace(', Groupy!', newWelcomeMessage); } const profileNameElement = document.querySelector('h2.text-5xl.font-semibold'); if (profileNameElement && profileNameElement.textContent.includes('Groupy Pro')) { profileNameElement.textContent = newName; } } }
    function modifySiderAI() { if (window.location.hostname.includes('sider.ai')) { const newIconUrl = PROFILE_ICON_URL; const newName = "Gracely Premium"; const newEmail = "premium@gracely.com"; const avatarSelectors = ['div.size-\\[30px\\] img', 'div.f-i-center img.size-\\[32px\\].rounded-full', 'div.ant-popover-content img.size-\\[48px\\].rounded-full', 'div.group.relative.w-\\[64px\\] img', 'div.h-\\[48px\\]\\.w-\\[48px\\] img', 'div.box-content.h-\\[27px\\] img']; document.querySelectorAll(avatarSelectors.join(', ')).forEach(img => { if (img.src !== newIconUrl) { img.src = newIconUrl; img.alt = newName; Object.assign(img.style, { objectFit: 'cover' }); } }); const nameSelectors = ['div.font-medium-18.text-color-text-primary-1', 'p.text-\\[16px\\].leading-\\[24px\\]', 'div.text-\\[20px\\].font-\\[600\\]']; document.querySelectorAll(nameSelectors.join(', ')).forEach(element => { if (element.textContent.includes('Groupy') || element.textContent.includes('Sider')) { element.textContent = newName; } }); document.querySelectorAll('p.text-text-level-3.font-normal').forEach(p => { if (p.textContent.includes('@')) { p.textContent = newEmail; } }); } }
    function modifyCoohomProfileIcon() { if (window.location.hostname.includes('coohom.com')) { const newIconUrl = `url("${PROFILE_ICON_URL}")`; const selector = 'div[alt="avatar"].BaseDiv-hmiwxo.ImgNoTheme-ejyemx.DBPhb'; document.querySelectorAll(selector).forEach(div => { if (div.style.backgroundImage !== newIconUrl) { div.style.backgroundImage = newIconUrl; div.style.backgroundSize = 'cover'; div.style.backgroundPosition = 'center'; } }); } }
    function blockButton(button) { if (button.dataset.logoutBlocked) return; button.dataset.logoutBlocked = 'true'; button.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); window.location.href = BLOCKED_URL; }, true); }
    function findAndBlockLogoutButtons(targetNode = document.body) {
        if (!targetNode || !targetNode.querySelectorAll) return;

        const hostname = window.location.hostname.replace('www.', '');
        const matchingDomain = Object.keys(SITE_SELECTORS).find(domain => hostname.includes(domain));

        if (matchingDomain) {
            SITE_SELECTORS[matchingDomain].forEach(selector => {
                try {
                    targetNode.querySelectorAll(selector).forEach(blockButton);
                    // Jika node itu sendiri yang cocok (untuk kasus addedNode adalah tombolnya)
                    if (targetNode.matches && targetNode.matches(selector)) blockButton(targetNode);
                } catch (e) { }
            });
        }

        // Scan for heuristic keywords
        const scanElement = (el) => {
            if (el.dataset.logoutBlocked) return;
            // ... existing heuristic logic but optimized ...
            // Untuk optimasi, kita pending heuristic scan yang berat jika node terlalu banyak (misal full page load)
            // TAPI, di sini kita sederhanakan:
            if (el.matches && ['A', 'BUTTON'].includes(el.tagName)) {
                blockButton(el); // Just apply listener, logic is inside blockButton to check "is this REALLY a logout button?"
                // Wait, blockButton assumes it IS a logout button. We need the check logic back.
                // Let's restore full logic but only for the target element and its children.
            }
        };

        const candidates = targetNode.querySelectorAll ? targetNode.querySelectorAll('a, button, [role="button"], [role="menuitem"], [onclick]') : [];
        candidates.forEach(el => checkAndBlock(el));
        if (targetNode.matches && targetNode.matches('a, button, [role="button"], [role="menuitem"], [onclick]')) checkAndBlock(targetNode);
    }

    function checkAndBlock(el) {
        if (el.dataset.logoutBlocked) return;
        let textToSearch = ((el.getAttribute('href') || '') + ' ' + (el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '') + ' ' + (el.className && typeof el.className === 'string' ? el.className : '') + ' ' + (el.id || '')).toLowerCase();
        if (HEURISTIC_KEYWORDS.some(keyword => textToSearch.includes(keyword)) && el.offsetParent !== null) {
            blockButton(el);
        }
    }

    const HOST_FUNCTION_MAP = {
        'medium.com': [modifyMedium],
        'netflix.com': [modifyNetflixProfileIcons],
        'masterclass.com': [modifyMasterClassProfileIcons],
        'primevideo.com': [modifyPrimeVideoProfileIcons],
        'chatgpt.com': [applyChatGptStyleOverride],
        'perplexity.ai': [modifyPerplexityProfileIcons],
        'academia.edu': [modifyAcademiaProfileIcons, modifyAcademiaAccountNames],
        'scribd.com': [modifyScribdProfileIcon],
        'crunchyroll.com': [modifyCrunchyrollProfileIcons],
        'iloveimg.com': [modifyILoveSites],
        'ilovepdf.com': [modifyILoveSites],
        'quizlet.com': [modifyQuizletProfileIcon],
        'speechify.com': [modifySpeechifyProfileIcon],
        'musicbed.com': [modifyMusicbedProfileIcon],
        'svgator.com': [modifySvgatorProfileIcon],
        'everand.com': [modifyEverandProfileIcon],
        'busuu.com': [modifyBusuuProfileIcon],
        'deepl.com': [modifyDeeplLogo],
        'askyourpdf.com': [modifyAskYourPdf],
        'mubi.com': [modifyMubiProfilePictures],
        'bilibili.tv': [modifyBilibili],
        'rawpixel.com': [modifyRawpixelProfile],
        'educative.io': [modifyEducativeProfile],
        'slideshare.net': [modifySlideshare],
        'sider.ai': [modifySiderAI],
        'coohom.com': [modifyCoohomProfileIcon]
    };

    let scheduledAnimationFrame = null;

    // --- OPTIMIZED OBSERVER CALLBACK ---
    const observerCallback = (mutations) => {
        if (scheduledAnimationFrame) return;

        scheduledAnimationFrame = requestAnimationFrame(() => {
            // 1. Jalankan Site Specific Modifiers (ini biasanya cepat karena pakai selector spesifik)
            // Kita jalankan HANYA jika ada mutasi (yang memang terjadi, makanya callback dipanggil)
            activeFunctions.forEach(func => func());

            // 2. Optimized Text Replacement & Button Blocking
            mutations.forEach(mutation => {
                mutation.addedNodes.forEach(node => {
                    // Hanya proses node ELEMENT dan TEXT
                    if (node.nodeType === 1) { // ELEMENT_NODE
                        modifyGroupyToGracely(node); // Scan teks di dalam elemen baru ini saja
                        findAndBlockLogoutButtons(node); // Scan tombol logout di dalam elemen baru ini saja
                    } else if (node.nodeType === 3) { // TEXT_NODE
                        processTextNode(node);
                    }
                });
            });

            scheduledAnimationFrame = null;
        });
    };
    // -----------------------------------

    const observer = new MutationObserver(observerCallback);
    let activeFunctions = [];

    async function initializeFeatures() {
        await fetchConfig();
        replaceUrlHash();
        window.addEventListener('hashchange', replaceUrlHash);

        const hostname = window.location.hostname;
        // modifyGroupyToGracely tidak dimasukkan ke activeFunctions loop global lagi
        // karena sekarang dipanggil spesifik per mutasi node.

        Object.keys(HOST_FUNCTION_MAP).forEach(domain => {
            if (hostname.includes(domain)) {
                activeFunctions.push(...HOST_FUNCTION_MAP[domain]);
            }
        });

        if (activeFunctions.length > 0 || Object.keys(SITE_SELECTORS).some(d => hostname.includes(d))) {
            // Initial Run (Full Scan Sekali Saja)
            activeFunctions.forEach(func => func());
            modifyGroupyToGracely(document.body); // Full scan awal
            findAndBlockLogoutButtons(document.body); // Full scan awal

            // Start Observer
            observer.observe(document.body, { childList: true, subtree: true }); // Removed characterData: true for perf unless critical
            console.log(`[Gracely Guard] Optimized for ${hostname}. Tracking DOM changes.`);
        }
    }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', initializeFeatures); } else { initializeFeatures(); }
} else { console.log('[Gracely Guard] Sesi Gracely TIDAK AKTIF. Skrip modifyer tidak berjalan.'); }
document.addEventListener('contextmenu', event => event.preventDefault());
document.addEventListener('keydown', function (e) { if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I') || (e.ctrlKey && e.shiftKey && e.key === 'J') || (e.ctrlKey && e.key === 'U')) { e.preventDefault(); } });