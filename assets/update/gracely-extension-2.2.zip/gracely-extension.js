const originalConsoleLog = console.log;
const DEBUG_MODE = false;
if (!DEBUG_MODE) {
    console.log = () => {};
    console.warn = () => {};
    console.error = () => {};
}

// --- SECURE STORAGE LAYER ---
const SECURE_KEY_STORAGE = "Gracely_Secure_Local_2026";
const SECURE_MAPPING = {
    'remote_config': '_sys_cfg_r1',
    'configEtag': '_sys_tag_e1',
    'favoriteServices': '_usr_fav_s1',
    'lastInjectedServiceId': '_sys_inj_l1',
    'cachedServices': '_dat_svc_c1',
    'cachedUserPlanId': '_dat_pln_c1',
    'user_plan_id': '_usr_id_p1',
    'session_config': '_ses_cfg_s1',
    'sessionEtag': '_ses_tag_e1',
    'serviceEtag': '_svc_tag_e1',
    'premiumExpiryDate': '_usr_exp_d1',
    'pro_expiry_date': '_usr_exp_d2',
    'phantom_expiry_date': '_usr_exp_d3',
    'x_client_sync_meta': '_sys_key_m1',
    'premium_status': '_usr_sts_p1',
    'premium_configUrl': '_sys_url_c1',
    'cleanupRequiredOnStartup': '_sys_cln_u1',
    'sessionInjectionHistory': '_ses_his_i1',
    'injectedServices': '_ses_inj_s1',
    'folderInfoLastShown': '_ui_fld_s1',
    'categoriesHidden': '_ui_cat_h1',
    'lastMaintenanceTimestamp': '_sys_mnt_t1',
    'cache_timestamp': '_sys_tms_c1',
    'selectedCategory': '_usr_cat_act1'
};
// --- HYBRID LEGACY SUPPORT ---
function legacyObfuscate(e) {
    try {
        const t = SECURE_KEY_STORAGE;
        let r = "";
        for (let n = 0; n < e.length; n++) r += String.fromCharCode(e.charCodeAt(n) ^ t.charCodeAt(n % t.length));
        return btoa(r)
    } catch (t) {
        return e
    }
}

function legacyDeobfuscate(e) {
    try {
        const t = SECURE_KEY_STORAGE,
            r = atob(e);
        let n = "";
        for (let e = 0; e < r.length; e++) n += String.fromCharCode(r.charCodeAt(e) ^ t.charCodeAt(e % t.length));
        return n
    } catch (t) {
        return e
    }
}

// --- MODERN NATIVE CRYPTO ---
let cachedKey = null;
async function getCryptoKey() {
    if (cachedKey) return cachedKey;
    const enc = new TextEncoder();
    const keyMaterial = await window.crypto.subtle.importKey("raw", enc.encode(SECURE_KEY_STORAGE), {
        name: "PBKDF2"
    }, false, ["deriveKey"]);
    return cachedKey = await window.crypto.subtle.deriveKey({
        name: "PBKDF2",
        salt: enc.encode("Gracely_Salt_v1"),
        iterations: 100000,
        hash: "SHA-256"
    }, keyMaterial, {
        name: "AES-GCM",
        length: 256
    }, false, ["encrypt", "decrypt"]);
}

async function encryptData(data) {
    try {
        const key = await getCryptoKey();
        const iv = window.crypto.getRandomValues(new Uint8Array(12));
        const enc = new TextEncoder();
        const encrypted = await window.crypto.subtle.encrypt({
            name: "AES-GCM",
            iv: iv
        }, key, enc.encode(data));
        const combined = new Uint8Array(iv.length + encrypted.byteLength);
        combined.set(iv);
        combined.set(new Uint8Array(encrypted), iv.length);
        let binary = '';
        const len = combined.byteLength;
        for (let i = 0; i < len; i++) binary += String.fromCharCode(combined[i]);
        return 'Gv2:' + btoa(binary);
    } catch (e) {
        return legacyObfuscate(data);
    }
}

async function decryptData(data) {
    if (!data) return null;
    if (!data.startsWith('Gv2:')) return legacyDeobfuscate(data); // Legacy fallback
    try {
        const raw = atob(data.substring(4));
        const customBuffer = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) customBuffer[i] = raw.charCodeAt(i);
        const iv = customBuffer.slice(0, 12);
        const ciphertext = customBuffer.slice(12);
        const key = await getCryptoKey();
        const decrypted = await window.crypto.subtle.decrypt({
            name: "AES-GCM",
            iv: iv
        }, key, ciphertext);
        return new TextDecoder().decode(decrypted);
    } catch (e) {
        return null;
    }
}

const secureStorage = {
    _mem: {},
    get: async e => {
        let t = [],
            r = !1;
        "string" == typeof e ? (t = [e], r = !0) : t = Array.isArray(e) ? e : Object.keys(e);
        const result = {};
        const missing = [];
        t.forEach(k => {
            if (secureStorage._mem[k] !== undefined) result[k] = secureStorage._mem[k];
            else missing.push(k);
        });
        if (missing.length === 0) return result;
        const n = missing.map(e => SECURE_MAPPING[e] || e);
        const o = await chrome.storage.local.get(n);
        await Promise.all(missing.map(async e => {
            const mapKey = SECURE_MAPPING[e] || e;
            if (void 0 !== o[mapKey]) {
                try {
                    const decrypted = await decryptData(o[mapKey]);
                    const val = JSON.parse(decrypted);
                    result[e] = val;
                    secureStorage._mem[e] = val;
                } catch (r) {
                    result[e] = o[mapKey];
                    secureStorage._mem[e] = o[mapKey];
                }
            }
        }));
        return result;
    },
    set: async e => {
        const t = {};
        const promises = [];
        for (const [r, n] of Object.entries(e)) {
            secureStorage._mem[r] = n;
            const mapKey = SECURE_MAPPING[r] || r;
            const p = encryptData(JSON.stringify(n)).then(enc => {
                t[mapKey] = enc;
            });
            promises.push(p);
        }
        await Promise.all(promises);
        return chrome.storage.local.set(t)
    },
    remove: async e => {
        const t = Array.isArray(e) ? e : [e];
        t.forEach(k => delete secureStorage._mem[k]);
        const r = t.map(e => SECURE_MAPPING[e] || e);
        return chrome.storage.local.remove(r)
    }
};
// ----------------------------

document.addEventListener('DOMContentLoaded', () => {
    const mainContainer = document.querySelector('main.tly');
    const loadedContainer = document.getElementById('loaded');
    const loadingContainer = document.getElementById('loading');
    const erroredContainer = document.getElementById('errored');
    const appSearch = document.getElementById('appSearch');
    const searchIcon = document.getElementById('searchIcon');
    const toggleFiltersButton = document.getElementById('toggleFilters');
    const filtersContainer = document.getElementById('categoryFiltersContainer');
    const categoryFilters = document.querySelector('.category-filters');
    const refreshButton = document.getElementById('refreshButton');
    const logoutButton = document.getElementById('safeLogout');
    const logoImage = document.getElementById('logoImage');
    const themeLightButton = document.getElementById('theme-light');
    const themeDarkButton = document.getElementById('theme-dark');
    const tutorialButton = document.getElementById('tutorial');
    const purchaseButton = document.getElementById('purchase');
    const footerText = document.getElementById('footer');
    const authStatusBanner = document.getElementById('auth-status-banner');
    let allServices = [];
    let typewriterTimeout;
    let favoriteServices = [];
    let lastInjectedServiceId = null;
    let remoteFolderInfo = {};
    let helpButton;
    let noticeIcon;
    let currentServiceGroup = null;
    let globalConfig = {};
    let countdownInterval;
    let hasLoggedOutForMaintenance = false;
    let retryAttempt = 0;

    function showError(message) {
        loadingContainer.style.display = 'none';
        loadedContainer.classList.add('d-none');
        erroredContainer.innerHTML = `<p>${message}</p>`;
        erroredContainer.classList.remove('d-none');
    }
    async function handleInitializationError(error) {
        console.error(`Gagal memuat data live:`, error);
        if (typeof typewriterTimeout !== 'undefined') clearTimeout(typewriterTimeout);
        appSearch.placeholder = "Connecting...";
        if (searchIcon) searchIcon.className = 'fa fa-solid fa-globe search-icon fa-fade';
        if (authStatusBanner) authStatusBanner.style.display = 'none';
        appSearch.disabled = true;
        
        loadingContainer.style.display = 'flex';
        loadedContainer.classList.add('d-none');
        erroredContainer.classList.add('d-none');
        
        // Retry otomatis setelah beberapa detik jika gagal
        setTimeout(() => {
            initializePopup();
        }, 3000);
    }

    // --- STATE MANAGEMENT (IN-MEMORY) ---
    // Gunakan variabel memori agar reset saat popup ditutup, tapi bertahan saat refresh internal.
    // --- STATE MANAGEMENT (IN-MEMORY) ---
    // Gunakan variabel memori agar reset saat popup ditutup, tapi bertahan saat refresh internal.
    let currentActiveCategories = ['all'];
    let isUpdateRequired = false;

    async function refreshData(force = false) {
        // Helper to simplify refresh logic if needed later
    }

    async function initializePopup() {
        const popupStartTime = Date.now(); // Start timer for dynamic delay
        const isPopupMode = window.innerWidth < 800;
        if (countdownInterval) clearInterval(countdownInterval);
        if (authStatusBanner) authStatusBanner.style.display = 'none';
        const modalContainer = document.getElementById('notification-0');
        if (modalContainer) modalContainer.style.display = 'none';

        // --- OFFLINE CHECK ---
        if (!navigator.onLine) {
            console.log("Offline mode detected. Infinity loading active.");
            loadingContainer.style.display = 'flex';
            loadedContainer.classList.add('d-none');
            erroredContainer.classList.add('d-none');
            if (appSearch) appSearch.placeholder = "Connecting...";
            if (searchIcon) searchIcon.className = 'fa fa-solid fa-globe search-icon fa-fade';

            // Start a retry loop or just wait for online event
            const retryWhenOnline = () => {
                if (navigator.onLine) {
                    window.removeEventListener('online', retryWhenOnline);
                    initializePopup();
                }
            };
            window.addEventListener('online', retryWhenOnline);
            return;
        }

        // -- INITIALIZE COMMUNICATION EARLY --
        chrome.runtime.sendMessage({ action: "refreshBlockingRules" }).catch(e => console.warn("Gagal sinkronisasi background", e));
        
        // --- 1. GET PREMIUM STATUS WITH TIMEOUT ---
        const messagePromise = chrome.runtime.sendMessage({ action: "getPremiumStatus" });
        const SERVER_GRACE_PERIOD_MS = 300; // Batas kesabaran Data-Driven Cache (ms)
        const TIMEOUT_MS = 10000;           // Batas error total koneksi
        
        // --- PRE-FETCH LOCAL DATA UNTUK OPTIMISTIC UI 0-MS ---
        const stored = await secureStorage.get([
            'remote_config', 'favoriteServices', 'lastInjectedServiceId', 
            'cachedServices', 'cachedUserPlanId', 'user_plan_id',
            'premiumExpiryDate', 'pro_expiry_date', 'phantom_expiry_date'
        ]);
        const remote_config = stored.remote_config || {};
        const cachedServices = stored.cachedServices || null;
        globalConfig = remote_config;

        const now = new Date();
        const pDate = stored.premiumExpiryDate ? new Date(stored.premiumExpiryDate) : null;
        const proDate = stored.pro_expiry_date ? new Date(stored.pro_expiry_date) : null;
        const phanDate = stored.phantom_expiry_date ? new Date(stored.phantom_expiry_date) : null;
        const isLocalPremiumValid = (pDate && now <= pDate) || (proDate && now <= proDate) || (phanDate && now <= phanDate);
        const isPlanValid = stored.user_plan_id && stored.cachedUserPlanId === stored.user_plan_id;
        
        let loginStatus = null;
        let isUIRenderedFromCache = false;
        let pendingCacheRender = null; // Tambahkan flag penahan UI

        if (cachedServices && isLocalPremiumValid && isPlanValid) {
            console.log("✅ Local Data Valid! Menahan re-render sampai pengecekan ETag selesai.");
            
            // Siapkan data, TAPI jangan dirender ke layar, biarkan state Loading berjalan.
            remoteFolderInfo = globalConfig.notifications?.folderInfo || {};
            favoriteServices = stored.favoriteServices || [];
            lastInjectedServiceId = stored.lastInjectedServiceId || null;
            allServices = cachedServices;
            
            pendingCacheRender = () => {
                // Proses render dari cache dilempar ke sini, hanya dieksekusi jika server membalas 304 atau timeout
                loadedContainer.classList.remove('d-none');
                erroredContainer.classList.add('d-none');
                loadingContainer.style.display = 'none';
                appSearch.disabled = false;
                
                let activeCatIds = [];
                cachedServices.forEach(s => {
                    if (Array.isArray(s.meta.category)) activeCatIds.push(...s.meta.category);
                    else if (s.meta.category) activeCatIds.push(s.meta.category);
                });
                const uniqueCats = [...new Set(activeCatIds.map(c => c.toLowerCase().replace(/\s/g, '')))];
                document.querySelectorAll('.category-filter').forEach(btn => {
                    const cat = btn.dataset.category;
                    if (cat === 'all' || uniqueCats.includes(cat)) btn.disabled = false;
                });

                displayMainView(cachedServices);
                
                // Restore previous clicked category
                let savedCategories = currentActiveCategories || ['all'];
                if (!Array.isArray(savedCategories)) savedCategories = [savedCategories];
                document.querySelectorAll('.category-filter').forEach(b => b.classList.remove('active'));
                let anyAct = false;
                savedCategories.forEach(cat => {
                    const tb = document.querySelector(`.category-filter[data-category="${cat}"]`);
                    if (tb && !tb.disabled) { tb.classList.add('active'); anyAct = true; }
                });
                if (!anyAct) {
                    const allBtn = document.querySelector('.category-filter[data-category="all"]');
                    if (allBtn) { allBtn.classList.add('active'); currentActiveCategories = ['all']; }
                }
                filterAndSearch();

                initializeNotificationFeature();
                setTimeout(() => { appSearch.focus(); }, 100);
                startTypewriter(cachedServices.map(s => s.meta.name));
                isUIRenderedFromCache = true;
            };
        } else {
            console.log("❌ Local Cache invalid/expired. Loading Server Module.");
            if (loadedContainer.classList.contains('d-none')) {
                appSearch.placeholder = "Connecting...";
                appSearch.disabled = false;
                if (searchIcon) searchIcon.className = 'fa fa-solid fa-globe search-icon fa-fade';
                loadingContainer.style.display = 'flex';
            }
        }

        // TUNGGU PENGECEKAN AUTENTIKASI BACKGROUND SECARA MUTLAK (Tanpa Timeout)
        try {
            loginStatus = await messagePromise;
        } catch (err) {
            console.warn("Final Init Error:", err);
            handleInitializationError(err);
            return;
        }
        // (Variabel stored, remote_config, dan cachedServices sudah diekstraksi di atas)

        // vvv RESTORED MISSING LOGIC vvv
        if (globalConfig.versionControl) {
            const vCtrl = globalConfig.versionControl;
            const currentVer = chrome.runtime.getManifest().version;
            const reqVer = vCtrl.requiredExtensionVersion;
            const reqGuardVer = vCtrl.requiredGuardVersion;

            let guardInfo = null;
            try {
                const allExt = await new Promise(r => chrome.management.getAll(r));
                guardInfo = allExt.find(e => e.name === "Gracely Guard");
            } catch (e) {}

            if (currentVer !== reqVer || (guardInfo && guardInfo.version !== reqGuardVer)) {
                // 1. Mark warning as shown IMMEDIATELY via storage
                await chrome.storage.local.set({
                    updateWarningShown: true
                });
                isUpdateRequired = true; // Flag for renderUI logic

                // 2. Show the Modal (Overlay on top of loading/loaded UI)
                showUpdateModal(vCtrl);

                // 3. ALLOW EXECUTION TO CONTINUE
                // We do NOT return different than before. We want the UI (`renderUI`) to run
                // so the user sees the icons in the background of the modal.
            }
        }


        // --- NETWORK ERROR HANDLING ---
        if (loginStatus && loginStatus.status === 'network_error') {
            console.log("Strict Mode: Menahan layar pada Infinity Loading saat jaringan offline / tidak dapat mengakses API.");
            handleInitializationError(new Error("Jaringan offline."));
            return;
        }

        if (!loginStatus || loginStatus.status === 'logged_out') {
            if (typeof typewriterTimeout !== 'undefined') clearTimeout(typewriterTimeout);
            loadingContainer.style.display = 'flex';
            loadedContainer.classList.add('d-none'); // Force hide cache if logged out
            appSearch.placeholder = "Connecting...";
            appSearch.disabled = false;
            if (searchIcon) searchIcon.className = 'fa fa-solid fa-globe search-icon fa-fade';
            if (authStatusBanner) authStatusBanner.style.display = 'none';

            const modalContainer = document.getElementById('notification-0');
            if (modalContainer) modalContainer.style.display = 'none';

            // Panggil clean up ke background agar cache dibongkar total karena tertendang/token mati
            if (loginStatus?.status === 'logged_out') {
                try {
                    await chrome.runtime.sendMessage({ action: "logout" });
                } catch (err) { console.warn("Pembersihan cache gagal: ", err); }
            }

            // DELAY 2 DETIK SESUAI REQUEST
            await new Promise(resolve => setTimeout(resolve, 2000));

            showError(loginStatus?.message || "Please login to access Gracely Extension.");
            if (authStatusBanner) authStatusBanner.style.display = 'block';
            appSearch.placeholder = "UNAUTHORIZED";
            appSearch.disabled = true;
            if (searchIcon) searchIcon.className = 'fa fa-solid fa-warning search-icon fa-fade';
            await new Promise(resolve => setTimeout(resolve, 1000));
            const logoutRedirectUrl = globalConfig.urls?.onLoggedOutRedirect || "https://gracely011.github.io/hai/login.html";
            chrome.tabs.create({
                url: logoutRedirectUrl
            });
            if (isPopupMode) {
                window.close();
            }
            return;
        } else if (loginStatus.status === 'free') {
            if (typeof typewriterTimeout !== 'undefined') clearTimeout(typewriterTimeout);
            loadingContainer.style.display = 'flex';
            loadedContainer.classList.add('d-none');
            appSearch.placeholder = "Connecting...";
            appSearch.disabled = false;
            if (searchIcon) searchIcon.className = 'fa fa-solid fa-globe search-icon fa-fade';
            if (authStatusBanner) authStatusBanner.style.display = 'none';

            const modalContainer = document.getElementById('notification-0');
            if (modalContainer) modalContainer.style.display = 'none';

            await new Promise(resolve => setTimeout(resolve, 500));
            showError("Premium is required to access Gracely Extension.");
            if (authStatusBanner) authStatusBanner.style.display = 'block';
            appSearch.placeholder = "NOT_PREMIUM";
            appSearch.disabled = true;
            if (searchIcon) searchIcon.className = 'fa fa-solid fa-warning search-icon fa-fade';
            await new Promise(resolve => setTimeout(resolve, 1000));
            const freeRedirectUrl = globalConfig.urls?.onFreeUserRedirect || "https://gracely011.github.io/hai/premium.html";
            chrome.tabs.create({
                url: freeRedirectUrl
            });
            if (isPopupMode) {
                window.close();
            }
            return;
        } else if (loginStatus.status === 'premium' && loginStatus.configUrl) {
            // ^^^ RESTORED MISSING LOGIC ^^^

            // --- CACHING STRATEGY: FULL WAIT (Tunggu Semua Selesai) ---
            // Kita siapkan cache, tapi JANGAN render dulu.
            // User ingin loading selesai sepenuhnya baru UI tampil, supaya tidak ada glitch update di tengah.

            // VALIDASI PLAN: Pastikan plan tidak berubah
            const isPlanValid = stored.user_plan_id && stored.cachedUserPlanId === stored.user_plan_id;
            const validCacheAvailable = cachedServices && isPlanValid;

            try {
                // --- SUPABASE LAZY FETCH LOGIC WITH ETAG ---
                const SUPABASE_URL = "https://mujasmmlozswplmtkijr.supabase.co";
                const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im11amFzbW1sb3pzd3BsbXRraWpyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE3MDM4ODgsImV4cCI6MjA3NzI3OTg4OH0.tttyPcoVUtyPLfBm1irS2qYthzt84Yb0OhjxD-tZ4Nw";
                
                const { serviceEtag } = await secureStorage.get('serviceEtag');
                const headers = {
                    'apikey': SUPABASE_KEY,
                    'Authorization': `Bearer ${SUPABASE_KEY}`
                };
                
                // Gunakan ETag jika data di cache masih relevan (Plan sama & Data ada)
                if (validCacheAvailable && serviceEtag) {
                    headers['If-None-Match'] = serviceEtag;
                }

                // FETCH DATA METADATA SAJA
                const liveDataResponse = await fetch(`${SUPABASE_URL}/rest/v1/gracely_services?select=id,service_name,category,icon_url,static_id,is_folder,url`, {
                    headers: headers
                });

                if (liveDataResponse.status === 304 && validCacheAvailable) {
                    console.log("⚡ [ETAG 304 Not Modified] Data Supabase Dikonfirmasi Sinkron. Memakai Cache Lokal.");
                    // Matikan loading spinner
                    loadingContainer.style.display = 'none';
                    loadedContainer.classList.remove('d-none');
                    erroredContainer.classList.add('d-none');
                    appSearch.disabled = false;
                    appSearch.placeholder = "";
                    if (searchIcon) searchIcon.className = 'fa fa-search search-icon';

                    await renderUI(remote_config || {}, cachedServices);
                } else if (liveDataResponse.ok) {
                    const newEtag = liveDataResponse.headers.get('etag');
                    if (newEtag) {
                        await secureStorage.set({ serviceEtag: newEtag });
                    }
                    
                    const rawRows = await liveDataResponse.json();

                    // Grouping Logic (Recreating the generator's behavior dynamically based on Name)
                    const groupedMap = {};
                    rawRows.forEach(row => {
                        const key = row.service_name;
                        if (!groupedMap[key]) {
                            groupedMap[key] = {
                                meta: {
                                    id: row.static_id || row.id,
                                    name: row.service_name,
                                    category: row.category ? row.category.split(',') : [],
                                    icon: row.icon_url,
                                    url: row.url,
                                    staticId: row.static_id,
                                    isGroup: false
                                },
                                _dbRows: [] 
                            };
                        }
                        groupedMap[key]._dbRows.push(row);
                    });

                    let services = Object.values(groupedMap).map(service => {
                        if (service._dbRows.length > 1) {
                            service.meta.isGroup = true;
                            service.accounts = service._dbRows.map((r, idx) => {
                                let accName = r.service_name;
                                if (!accName || accName === service.meta.name) {
                                    accName = `${service.meta.name} ${idx + 1}`;
                                }
                                return {
                                    id: r.id,
                                    name: accName,
                                    _lazyRowId: r.id,
                                    sourceUrl: r.url
                                };
                            });
                        } else {
                            service._lazyRowId = service._dbRows[0].id;
                        }
                        delete service._dbRows;
                        return service;
                    });

                    // --- PLAN BASED FILTERING START ---
                    const {
                        premiumExpiryDate,
                        pro_expiry_date,
                        phantom_expiry_date
                    } = await secureStorage.get(['premiumExpiryDate', 'pro_expiry_date', 'phantom_expiry_date']);
                    const now = new Date();
                    const isPremiumValid = premiumExpiryDate && now <= new Date(premiumExpiryDate);
                    const isProValid = pro_expiry_date && now <= new Date(pro_expiry_date);
                    const isPhantomValid = phantom_expiry_date && now <= new Date(phantom_expiry_date);

                    if (Array.isArray(services) && services.length > 0) {
                        services.sort((a, b) => {
                            const nameA = a.meta.name.toLowerCase();
                            const nameB = b.meta.name.toLowerCase();
                            return nameA.localeCompare(nameB);
                        });

                        services = services.filter(service => {
                            const catRaw = service.meta.category;
                            const category = Array.isArray(catRaw) ? catRaw.map(c => c.toLowerCase().replace(/\s/g, '')) : (catRaw ? catRaw.toLowerCase().replace(/\s/g, '') : "uncategorized");
                            const hasCategory = (target) => {
                                if (Array.isArray(category)) return category.includes(target);
                                return category === target;
                            };

                            if (isPhantomValid) return true;
                            else if (isProValid) {
                                if (hasCategory('phantomexclusive')) return false;
                                return true;
                            } else if (isPremiumValid) {
                                if (hasCategory('proexclusive') || hasCategory('phantomexclusive')) return false;
                                return true;
                            } else {
                                if (hasCategory('proexclusive') || hasCategory('phantomexclusive')) return false;
                                return true;
                            }
                        });
                    }
                    // --- PLAN BASED FILTERING END ---

                    // Simpan data
                    await secureStorage.set({
                        cachedServices: services,
                        cachedUserPlanId: stored.user_plan_id
                    });

                    // RENDER DATA BARU SETELAH SELESAI
                    retryAttempt = 0;
                    console.log("Pendownloadan selesai! Menampilkan Data Supabase Langsung (Server Cepat -> 200 OK)");
                    
                    // Matikan loading spinner
                    loadingContainer.style.display = 'none';
                    loadedContainer.classList.remove('d-none');
                    erroredContainer.classList.add('d-none');
                    appSearch.disabled = false;
                    appSearch.placeholder = "";
                    if (searchIcon) searchIcon.className = 'fa fa-search search-icon';

                    await renderUI(remote_config || {}, services);
                } else {
                    throw new Error('Gagal memuat data layanan premium (live).');
                }

            } catch (error) {
                console.warn("Fetch Error (Strict Mode):", error);
                handleInitializationError(error);
            }
        } else {
            // Fallback for unknown status -> Treat as "Please login"
            showError("Please login to access Gracely Extension.");
            if (authStatusBanner) authStatusBanner.style.display = 'block';
            appSearch.placeholder = "UNAUTHORIZED";
            appSearch.disabled = true;
            if (searchIcon) searchIcon.className = 'fa fa-solid fa-warning search-icon fa-fade';
        }
    }
    // --- HELPER DECRYPTION FUNCTION ---
    async function decryptServiceData(encryptedObj, password) {
        try {
            const enc = new TextEncoder();
            const dec = new TextDecoder();

            // 1. Re-derive Key from Password
            const keyMaterial = await window.crypto.subtle.importKey(
                "raw",
                enc.encode(password), {
                    name: "PBKDF2"
                },
                false,
                ["deriveKey"]
            );

            // Decode Base64 to ArrayBuffer
            const fromBase64 = (str) => Uint8Array.from(atob(str), c => c.charCodeAt(0));
            const salt = fromBase64(encryptedObj.s);
            const iv = fromBase64(encryptedObj.i);
            const data = fromBase64(encryptedObj.d);

            const key = await window.crypto.subtle.deriveKey({
                    name: "PBKDF2",
                    salt: salt,
                    iterations: 100000,
                    hash: "SHA-256"
                },
                keyMaterial, {
                    name: "AES-GCM",
                    length: 256
                },
                true, // must be exportable? checking docs, usually false is fine for decrypt
                ["decrypt"]
            );

            // 2. Decrypt
            const decrypted = await window.crypto.subtle.decrypt({
                    name: "AES-GCM",
                    iv: iv
                },
                key,
                data
            );

            const decryptedText = dec.decode(decrypted);
            return JSON.parse(decryptedText);

        } catch (e) {
            console.error("Decryption Failed:", e);
            throw new Error("Gagal membuka kunci data (Password salah atau file rusak).");
        }
    }
    // --- HELPER DECRYPTION FUNCTION END ---

    // (attachListeners removed - deprecated)

    async function renderUI(config, services) {
        // --- SECONDARY VERSION CHECK (For Fresh Installs / Updates) ---
        if (config.versionControl) {
            const vCtrl = config.versionControl;
            const currentVer = chrome.runtime.getManifest().version;
            const reqVer = vCtrl.requiredExtensionVersion;
            const reqGuardVer = vCtrl.requiredGuardVersion;

            let guardInfo = null;
            try {
                const allExt = await new Promise(r => chrome.management.getAll(r));
                guardInfo = allExt.find(e => e.name === "Gracely Guard");
            } catch (e) {}

            if (currentVer !== reqVer || (guardInfo && guardInfo.version !== reqGuardVer)) {
                if (!isUpdateRequired) { // Only if not already caught in initializePopup
                    isUpdateRequired = true;
                    await chrome.storage.local.set({
                        updateWarningShown: true
                    });
                    showUpdateModal(vCtrl);
                }
            }
        }

        if (searchIcon) searchIcon.className = 'fa fa-search search-icon';
        if (authStatusBanner) authStatusBanner.style.display = 'none';
        const maintenanceStatus = checkMaintenanceStatus(config.maintenanceMode);
        if (maintenanceStatus.status === 'maintenance') {
            if (!hasLoggedOutForMaintenance) {
                chrome.runtime.sendMessage({
                    action: "logout"
                });
                hasLoggedOutForMaintenance = true;
                secureStorage.set({
                    lastMaintenanceTimestamp: Date.now()
                });
            }
            showLockedMaintenanceModal(maintenanceStatus.title, maintenanceStatus.message, maintenanceStatus.endTime);
            return;
        }
        await runMissedMaintenanceCheck(config);
        try {
            globalConfig = config;
            allServices = services;
            const stored = await secureStorage.get(['favoriteServices', 'lastInjectedServiceId']);
            favoriteServices = stored.favoriteServices || [];
            lastInjectedServiceId = stored.lastInjectedServiceId || null;
            remoteFolderInfo = globalConfig.notifications?.folderInfo || {};
            displayMainView(allServices);
            startTypewriter(allServices.map(s => s.meta.name));

            // Only init notifications if NO update pending
            if (!isUpdateRequired) {
                initializeNotificationFeature();
            }

            loadingContainer.style.display = 'none';
            loadedContainer.classList.remove('d-none');
            erroredContainer.classList.add('d-none');
            let activeCategories = [];
            allServices.forEach(service => {
                const category = service.meta.category;
                if (Array.isArray(category)) {
                    activeCategories.push(...category);
                } else if (category) {
                    activeCategories.push(category);
                }
            });
            activeCategories = [...new Set(activeCategories.map(c => c.toLowerCase().replace(/\s/g, '')))];
            appSearch.disabled = false;
            document.querySelectorAll('.category-filter').forEach(button => {
                const category = button.dataset.category;
                if (category === 'all') {
                    button.disabled = false;
                } else if (activeCategories.includes(category)) {
                    button.disabled = false;
                }
            });
            appSearch.focus();

            // Restore selected categories from MEMORY
            let savedCategories = currentActiveCategories || ['all'];
            if (!Array.isArray(savedCategories)) savedCategories = [savedCategories];

            // Reset UI Filters State
            document.querySelectorAll('.category-filter').forEach(btn => btn.classList.remove('active'));

            let anyActive = false;
            savedCategories.forEach(cat => {
                const targetButton = document.querySelector(`.category-filter[data-category="${cat}"]`);
                if (targetButton && !targetButton.disabled) {
                    targetButton.classList.add('active');
                    anyActive = true;
                }
            });

            // Fallback to 'all' if no valid categories found or restored
            if (!anyActive) {
                const allButton = document.querySelector('.category-filter[data-category="all"]');
                if (allButton) {
                    allButton.classList.add('active');
                    currentActiveCategories = ['all'];
                }
            }

            // Re-run filter to apply the restored category
            filterAndSearch();

            if (maintenanceStatus.status === 'warning') {
                showMaintenanceWarningModal(maintenanceStatus.title, maintenanceStatus.message, maintenanceStatus.timeRemaining);
            }

            // --- HTML SNAPSHOT LOGIC MOVED TO displayMainView & updateCacheSnapshot ---
            // This ensures cache is updated on EVERY change, not just initial render.

        } catch (renderError) {
            console.warn("Render Error (retrying...):", renderError);
            loadingContainer.style.display = 'flex';
            loadedContainer.classList.add('d-none');
            erroredContainer.classList.add('d-none');
            appSearch.placeholder = "Loading...";
            appSearch.disabled = false;
            if (searchIcon) searchIcon.className = 'fa fa-solid fa-globe search-icon fa-fade';
            if (authStatusBanner) authStatusBanner.style.display = 'none';
            handleInitializationError(renderError);
        }
    }

    function setupEventListeners() {
        toggleFiltersButton.addEventListener('click', () => {
            const isCurrentlyHidden = filtersContainer.classList.contains('hidden');
            setCategoryViewState(!isCurrentlyHidden);
            secureStorage.set({
                categoriesHidden: !isCurrentlyHidden
            });
        });
        appSearch.addEventListener('input', filterAndSearch);
        themeLightButton.addEventListener('click', () => applyTheme('light'));
        themeDarkButton.addEventListener('click', () => applyTheme('dark'));
        categoryFilters.addEventListener('click', (event) => {
            const button = event.target.closest('.category-filter');
            if (!button) return;
            const category = button.dataset.category;
            const allButton = categoryFilters.querySelector('[data-category="all"]');
            if (category === 'all') {
                categoryFilters.querySelectorAll('.category-filter').forEach(btn => btn.classList.remove('active'));
                allButton.classList.add('active');
            } else {
                allButton.classList.remove('active');
                button.classList.toggle('active');
                if (!categoryFilters.querySelector('.category-filter.active')) {
                    allButton.classList.add('active');
                }
            }

            // Save the currently active categories to MEMORY
            const activeBtns = categoryFilters.querySelectorAll('.category-filter.active');
            const newActiveCategories = Array.from(activeBtns).map(btn => btn.dataset.category);
            currentActiveCategories = newActiveCategories;
            filterAndSearch();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        refreshButton.addEventListener('click', async () => {
            const startTime = Date.now();
            refreshButton.classList.add('fa-spin');
            refreshButton.style.pointerEvents = 'none';

            // 1. Force Loading State UI
            clearTimeout(typewriterTimeout);
            appSearch.placeholder = "Connecting...";
            // appSearch.value = ''; // Jangan hapus value, agar pencarian tetap aktif setelah refresh!
            appSearch.disabled = false;
            if (searchIcon) searchIcon.className = 'fa fa-solid fa-globe search-icon fa-fade';
            if (authStatusBanner) authStatusBanner.style.display = 'none';

            loadingContainer.style.display = 'flex';
            loadedContainer.classList.add('d-none');
            loadedContainer.innerHTML = ''; // Clear old HTML to prevent flash of stale content

            retryAttempt = 0;

            try {
                try {
                    chrome.runtime.sendMessage({
                        action: "refreshBlockingRules"
                    });
                } catch (e) {
                    console.error("Gagal memicu update aturan blokir:", e);
                }

                // 2. Nuke All Caches
                await secureStorage.remove([
                    'configEtag', 'sessionEtag', 'session_config', // Config Caches
                    'cached_ui_html', 'cachedServices', 'serviceEtag', // Data & UI Caches
                    'cachedUserPlanId' // Plan Cache
                ]);

                // 3. Re-init (will fetch fresh since cache is gone)
                await initializePopup();
            } finally {
                const elapsedTime = Date.now() - startTime;
                const minSpinTime = 1000;
                const timeToWait = Math.max(0, minSpinTime - elapsedTime);
                setTimeout(() => {
                    refreshButton.classList.remove('fa-spin');
                    refreshButton.style.pointerEvents = 'auto';
                }, timeToWait);
            }
        });
        logoutButton.addEventListener('click', handleLogout);
        tutorialButton.addEventListener('click', () => {
            const targetUrl = globalConfig.urls?.tutorial || "https://gracely011.github.io/hai/tutorial.html";
            chrome.tabs.create({
                url: targetUrl
            });
        });
        purchaseButton.addEventListener('click', () => {
            const targetUrl = globalConfig.urls?.purchase || "https://gracely011.github.io/hai/premium.html";
            chrome.tabs.create({
                url: targetUrl
            });
        });
    }

    function initializeUI() {
        displayConsoleMessage();
        appSearch.disabled = false;
        appSearch.placeholder = "Connecting...";
        if (searchIcon) searchIcon.className = 'fa fa-solid fa-globe search-icon fa-fade';
        const manifest = chrome.runtime.getManifest();
        if (footerText) {
            const currentYear = new Date().getFullYear();
            footerText.textContent = `version ${manifest.version} — Gracely © 2024-${currentYear}`;
        }
        const iconContainer = document.querySelector('footer .icon-container');
        noticeIcon = document.createElement('i');
        Object.assign(noticeIcon, {
            id: 'noticeIcon',
            className: 'fas fa-bullhorn icon',
            title: 'Announcement',
            style: 'display: none;'
        });
        iconContainer.appendChild(noticeIcon);
        helpButton = document.createElement('i');
        Object.assign(helpButton, {
            id: 'help',
            className: 'fas fa-circle-question icon',
            title: 'Help',
            style: 'display: none;'
        });
        helpButton.addEventListener('click', () => {
            if (currentServiceGroup && remoteFolderInfo[currentServiceGroup.meta.id]) {
                showFolderInfoModal(remoteFolderInfo[currentServiceGroup.meta.id]);
            }
        });
        iconContainer.appendChild(helpButton);
        const savedTheme = localStorage.getItem('theme') || 'light';
        applyTheme(savedTheme);
        secureStorage.get(['categoriesHidden']).then((result) => {
            setCategoryViewState(result.categoriesHidden || false);
        });
    }

    function main() {
        initializeUI();
        setupEventListeners();
        initializePopup();
    }

    function checkMaintenanceStatus(config) {
        if (!config || !config.enabled) {
            return {
                status: 'live'
            };
        }
        const now = new Date();
        let startTime;
        if (config.scheduleType === 'daily') {
            const timeParts = config.dailyTime.split(':');
            startTime = new Date();
            startTime.setHours(timeParts[0], timeParts[1], timeParts[2], 0);
        } else if (config.scheduleType === 'specific') {
            startTime = new Date(config.specificDateTime);
        } else {
            return {
                status: 'live'
            };
        }
        const endTime = new Date(startTime.getTime() + config.durationMinutes * 60000);
        const warningTime = new Date(startTime.getTime() - config.countdownMinutes * 60000);
        if (now >= startTime && now < endTime) {
            return {
                status: 'maintenance',
                title: config.maintenanceTitle,
                message: config.maintenanceMessage,
                endTime: endTime
            };
        }
        if (now >= warningTime && now < startTime) {
            return {
                status: 'warning',
                title: config.warningTitle,
                message: config.warningMessage,
                timeRemaining: startTime.getTime() - now.getTime()
            };
        }
        hasLoggedOutForMaintenance = false;
        return {
            status: 'live'
        };
    }
    async function runMissedMaintenanceCheck(config) {
        try {
            const {
                lastMaintenanceTimestamp = 0
            } = await secureStorage.get('lastMaintenanceTimestamp');
            const maintenanceConfig = config.maintenanceMode;
            if (!maintenanceConfig || !maintenanceConfig.enabled || maintenanceConfig.scheduleType !== 'daily') {
                return;
            }
            const now = new Date();
            const timeParts = maintenanceConfig.dailyTime.split(':');
            const todaysMaintenanceTime = new Date();
            todaysMaintenanceTime.setHours(timeParts[0], timeParts[1], timeParts[2], 0);
            let mostRecentScheduleStartTime;
            if (now >= todaysMaintenanceTime) {
                mostRecentScheduleStartTime = todaysMaintenanceTime;
            } else {
                const yesterdaysMaintenanceTime = new Date();
                yesterdaysMaintenanceTime.setDate(now.getDate() - 1);
                yesterdaysMaintenanceTime.setHours(timeParts[0], timeParts[1], timeParts[2], 0);
                mostRecentScheduleStartTime = yesterdaysMaintenanceTime;
            }
            if (lastMaintenanceTimestamp < mostRecentScheduleStartTime.getTime()) {
                const newTimestamp = new Date().getTime();
                if (lastMaintenanceTimestamp === 0) {
                    // Eksekusi pertama. Jangan logout konyol ke *Scorched Earth*, cukup simpan tms saat ini.
                    await secureStorage.set({
                        lastMaintenanceTimestamp: newTimestamp
                    });
                } else {
                    chrome.runtime.sendMessage({
                        action: "logout"
                    });
                    await secureStorage.set({
                        lastMaintenanceTimestamp: newTimestamp
                    });
                }
            }
        } catch (error) {
            console.error('[Gracely] Error saat memeriksa maintenance terlewat:', error);
        }
    }

    function formatTimeRemaining(ms) {
        const totalSeconds = Math.floor(ms / 1000);
        const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
        const minutes = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
        const seconds = (totalSeconds % 60).toString().padStart(2, '0');
        if (parseInt(hours) > 0) {
            return `${hours}:${minutes}:${seconds}`;
        }
        return `${minutes}:${seconds}`;
    }

    function showMaintenanceWarningModal(title, message, timeRemaining) {
        if (countdownInterval) clearInterval(countdownInterval);
        const modalContainer = document.getElementById('notification-0');
        const modalContent = modalContainer.querySelector('.notificationModal-content');
        const modalHTML = ` <i class="fa fa-times close-icon" id="warning-close"></i> <h2>${title}</h2> <p>${message}</p> <div id="countdown-timer" style="font-size: 2rem; font-weight: 600; margin: 0; color: #000000;"></div> <button class="ud-main-btn" id="warning-ok">OK</button> `;
        modalContent.innerHTML = modalHTML;
        const countdownElement = document.getElementById('countdown-timer');
        let remaining = timeRemaining;

        function updateCountdown() {
            if (remaining <= 0) {
                clearInterval(countdownInterval);
                initializePopup();
                return;
            }
            countdownElement.textContent = formatTimeRemaining(remaining);
            remaining -= 1000;
        }
        updateCountdown();
        countdownInterval = setInterval(updateCountdown, 1000);
        const closeModal = () => {
            clearInterval(countdownInterval);
            modalContainer.style.display = 'none';
        };
        modalContainer.querySelector('#warning-close').addEventListener('click', closeModal);
        modalContainer.querySelector('#warning-ok').addEventListener('click', closeModal);
        modalContainer.style.display = 'flex';
        modalContainer.style.opacity = '1';
        modalContainer.style.visibility = 'visible';
    }

    function showLockedMaintenanceModal(title, message, endTime) {
        if (countdownInterval) clearInterval(countdownInterval);
        loadingContainer.style.display = 'none';
        loadedContainer.classList.add('d-none');
        erroredContainer.classList.add('d-none');
        const modalContainer = document.getElementById('notification-0');
        const modalContent = modalContainer.querySelector('.notificationModal-content');
        const modalHTML = ` <h2 style="margin-bottom: 8px;">${title}</h2> <p>${message}</p> <p>Selesai dalam:</p> <div id="maintenance-duration-timer" style="font-size: 2rem; font-weight: 600; color: #000000;">--:--</div> `;
        modalContent.innerHTML = modalHTML;
        const countdownElement = document.getElementById('maintenance-duration-timer');

        function updateDuration() {
            const now = new Date().getTime();
            const remaining = endTime.getTime() - now;
            if (remaining <= 0) {
                clearInterval(countdownInterval);
                countdownElement.textContent = "Selesai!";
                setTimeout(() => {
                    hasLoggedOutForMaintenance = false;
                    window.close();
                }, 200);
                return;
            }
            countdownElement.textContent = formatTimeRemaining(remaining);
        }
        updateDuration();
        countdownInterval = setInterval(updateDuration, 1000);
        modalContainer.style.display = 'flex';
        modalContainer.style.opacity = '1';
        modalContainer.style.visibility = 'visible';
    }
    async function initializeNotificationFeature() {
        try {
            const t = globalConfig.notifications?.announcement;
            if (!t || !t.enabled || !t.id || !noticeIcon) {
                noticeIcon.style.display = "none";
                return;
            }
            noticeIcon.style.display = "block";

            let e = "";
            t.lines && Array.isArray(t.lines) && (e = t.lines.map(l => `<p>${l}</p>`).join(""));

            const n = t.html || `<i class="fa fa-times close-icon" id="notification-close"></i><h2>${t.title}</h2>${e}<button class="ud-main-btn" id="notification-ok">OK</button>`;
            const o = t.id;
            const i = document.getElementById("notification-0");
            const a = i.querySelector(".notificationModal-content");

            const s = () => {
                t.html ? i.innerHTML = t.html : a.innerHTML = n;
                i.style.display = "flex";
                i.style.opacity = "1";
                i.style.visibility = "visible";

                const closeHandler = () => {
                    i.style.display = "none";
                    localStorage.setItem("notificationLastShown", Date.now().toString());
                    localStorage.setItem("notificationLastShownId", o);
                };

                const closeBtn = i.querySelector("#notification-close");
                const okBtn = i.querySelector("#notification-ok");
                if (closeBtn) closeBtn.addEventListener("click", closeHandler);
                if (okBtn) okBtn.addEventListener("click", closeHandler);
            };

            noticeIcon.addEventListener("click", s);

            // --- 7 AM RESET LOGIC START ---
            const lastShownStr = localStorage.getItem("notificationLastShown");
            const lastId = localStorage.getItem("notificationLastShownId");

            let shouldShow = false;

            if (o !== lastId) {
                shouldShow = true; // New ID always shows
            } else if (!lastShownStr) {
                shouldShow = true; // Never shown
            } else {
                const now = new Date();
                const lastShown = new Date(parseInt(lastShownStr));

                // Set Reset Threshold (Today 07:00)
                let resetThreshold = new Date();
                resetThreshold.setHours(7, 0, 0, 0);

                // If it's currently before 7 AM, the last reset was Yesterday 7 AM
                if (now < resetThreshold) {
                    resetThreshold.setDate(resetThreshold.getDate() - 1);
                }

                // Show if last viewed BEFORE the latest reset threshold
                if (lastShown < resetThreshold) {
                    shouldShow = true;
                }
            }
            // --- 7 AM RESET LOGIC END ---

            if (shouldShow) {
                s();
            }

        } catch (err) {
            console.error("[Gracely Notif] Failed:", err);
        }
    }
    document.addEventListener('contextmenu', event => event.preventDefault());
    document.addEventListener('keydown', function (e) {
        if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I') || (e.ctrlKey && e.j) || (e.ctrlKey && e.key === 'U')) {
            e.preventDefault();
        }
    });
    async function toggleFavorite(serviceMeta) {
        // --- COMPOSITE ID FIX (Menambal ID Kembar) ---
        const compositeId = String(serviceMeta.id) + "_" + String(serviceMeta.name).trim();
        let currentFavorites = favoriteServices.map(String);
        
        const index = currentFavorites.indexOf(compositeId);
        if (index > -1) {
            currentFavorites.splice(index, 1);
        } else {
            // Backward compatibility search (kalau user masih simpan ID lama murni misal "chatgpt")
            const oldIndex = currentFavorites.indexOf(String(serviceMeta.id));
            if (oldIndex > -1 && !currentFavorites[oldIndex].includes("_")) {
                currentFavorites.splice(oldIndex, 1); // Hapus format lama
            }
            currentFavorites.push(compositeId);
        }
        await secureStorage.set({
            favoriteServices: currentFavorites
        });
        favoriteServices = currentFavorites;
        displayMainView(allServices);
    }

    function createCustomContextMenu(e, service) {
        const existingMenu = document.getElementById('customContextMenu');
        if (existingMenu) existingMenu.remove();
        e.preventDefault();
        e.stopPropagation();
        
        const compositeId = String(service.meta.id) + "_" + String(service.meta.name).trim();
        // Cek apakah ada di cache baru (komposit) atau cache usang (ID murni)
        const isFavorited = favoriteServices.includes(compositeId) || favoriteServices.includes(String(service.meta.id));
        const menuText = isFavorited ? `Unfavorite ${service.meta.name}` : `Favorite ${service.meta.name}`;
        const menu = document.createElement('div');
        menu.id = 'customContextMenu';
        Object.assign(menu.style, {
            position: 'absolute',
            backgroundColor: 'rgb(255, 255, 255)',
            border: '1px solid rgb(204, 204, 204)',
            borderRadius: '10px',
            padding: '5px',
            boxShadow: 'rgba(0, 0, 0, 0.3) 0px 2px 5px',
            zIndex: '10000',
            left: `${e.pageX}px`,
            top: `${e.pageY}px`
        });
        const option = document.createElement('div');
        option.id = 'contextFavoriteOption';
        option.innerHTML = `<i class="fas fa-star"></i> ${menuText}`;
        Object.assign(option.style, {
            cursor: 'pointer',
            padding: '5px',
            fontSize: '10px',
            color: '#000'
        });
        option.addEventListener('click', (event) => {
            event.stopPropagation();
            toggleFavorite(service.meta);
            menu.remove();
        });
        menu.appendChild(option);
        document.body.appendChild(menu);
        const closeMenu = () => {
            const menu = document.getElementById('customContextMenu');
            if (menu) menu.remove();
            window.removeEventListener('click', closeMenu, true);
        };
        setTimeout(() => window.addEventListener('click', closeMenu, true), 0);
    }

    function handleLogout() {
        if (window.confirm("Safely log out of Gracely accounts?")) {
            chrome.runtime.sendMessage({
                action: "logout"
            }, (response) => {
                if (chrome.runtime.lastError) {
                    return;
                }
            });
        }
    }

    function displayConsoleMessage() {
        const manifest = chrome.runtime.getManifest();
        const version = manifest.version;
        originalConsoleLog('%cGracely Extension ' + version, 'color: white; font-size: 20px; font-weight: bold; font-family: monospace; text-shadow: 2px 2px 4px #000000;');
        originalConsoleLog('%cUnlock Premium Together', 'color: #BEBEBE; font-size: 14px; font-family: monospace;');
        const currentYear = new Date().getFullYear();
        originalConsoleLog(`%cGracely © 2024-${currentYear}`, 'color: #888888; font-size: 12px; font-family: monospace;');
    }

    function startTypewriter(serviceNames) {
        if (!serviceNames || serviceNames.length === 0) {
            appSearch.placeholder = "";
            return;
        }
        clearTimeout(typewriterTimeout);
        let typeIndex = 0,
            charIndex = 0,
            isDeleting = false;
        const type = () => {
            const currentWord = serviceNames[typeIndex];
            appSearch.placeholder = currentWord.substring(0, charIndex);
            if (!isDeleting && charIndex === currentWord.length) {
                isDeleting = true;
                typewriterTimeout = setTimeout(type, 2000);
            } else if (isDeleting) {
                isDeleting = false;
                charIndex = 0;
                typeIndex = (typeIndex + 1) % serviceNames.length;
                typewriterTimeout = setTimeout(type, 500);
            } else {
                charIndex++;
                typewriterTimeout = setTimeout(type, 50);
            }
        };
        type();
    }

    function displayMainView(services) {
        currentServiceGroup = null;
        if (helpButton) {
            helpButton.style.display = 'none';
        }
        const oldSubfolderView = mainContainer.querySelector('.subfolder-view');
        if (oldSubfolderView) {
            oldSubfolderView.remove();
        }
        if (loadingContainer) loadingContainer.style.display = 'none'; // CRITICAL: Ensure loading is hidden
        loadedContainer.style.display = '';
        loadedContainer.innerHTML = '';
        if (!services || services.length === 0) {
            if (loadingContainer) loadingContainer.style.display = 'flex';
            loadedContainer.classList.add('d-none');
            if (erroredContainer) erroredContainer.classList.add('d-none');
            appSearch.placeholder = "Connecting...";
            appSearch.disabled = true;
            if (searchIcon) searchIcon.className = 'fa fa-solid fa-globe search-icon fa-fade';
            return;
        }
        const sortedServices = [...services].sort((a, b) => {
            // NORMALIZE FAVORITES COMPARISON WITH COMPOSITE ID
            const aCompId = String(a.meta.id) + "_" + String(a.meta.name).trim();
            const bCompId = String(b.meta.id) + "_" + String(b.meta.name).trim();
            const aIsFaved = favoriteServices.includes(aCompId) || favoriteServices.includes(String(a.meta.id));
            const bIsFaved = favoriteServices.includes(bCompId) || favoriteServices.includes(String(b.meta.id));
            if (aIsFaved === bIsFaved) return 0;
            return aIsFaved ? -1 : 1;
        });
        const fragment = document.createDocumentFragment();
        for (const service of sortedServices) {
            const serviceElement = createServiceElement(service);
            fragment.appendChild(serviceElement);
        }
        loadedContainer.appendChild(fragment);
        filterAndSearch();
    }

    function renderDetailView(serviceGroup) {
        currentServiceGroup = serviceGroup;
        loadedContainer.style.display = 'none';
        const oldSubfolderView = mainContainer.querySelector('.subfolder-view');
        if (oldSubfolderView) {
            oldSubfolderView.remove();
        }
        const subfolderView = document.createElement('div');
        subfolderView.className = 'subfolder-view fadeIn';
        const backButton = document.createElement('i');
        backButton.className = 'fas fa-arrow-left icon back-button';
        backButton.addEventListener('click', () => {
            displayMainView(allServices);
        });
        subfolderView.appendChild(backButton);
        const accountGrid = document.createElement('div');
        accountGrid.className = 'row';
        const randomCard = createRandomElement(serviceGroup);
        accountGrid.appendChild(randomCard);
        serviceGroup.accounts.forEach(account => {
            const accountElement = createAccountElement(account, serviceGroup.meta);
            accountGrid.appendChild(accountElement);
        });
        subfolderView.appendChild(accountGrid);
        mainContainer.appendChild(subfolderView);
        const serviceId = serviceGroup.meta.id;
        const info = remoteFolderInfo[serviceId];
        if (info) {
            if (helpButton) {
                helpButton.style.display = 'block';
            }
            const storageKey = 'folderInfoLastShown';
            secureStorage.get([storageKey]).then((result) => {
                const oneDay = 24 * 60 * 60 * 1000;
                const now = Date.now();
                const allTimestamps = result[storageKey] || {};
                const lastShown = allTimestamps[serviceId] || 0;
                if (!lastShown || (now - lastShown > oneDay)) {
                    showFolderInfoModal(info);
                    allTimestamps[serviceId] = now;
                    secureStorage.set({
                        [storageKey]: allTimestamps
                    });
                }
            });
        }
        filterAndSearch();
    }

    function showFolderInfoModal(info) {
        const modalContainer = document.getElementById('notification-0');
        const modalContent = modalContainer.querySelector('.notificationModal-content');
        let modalHTML;
        if (info.html) {
            modalHTML = info.html;
        } else {
            modalHTML = `<i class="fa fa-times close-icon" id="notification-close"></i><h2>${info.title}</h2>${info.content}<button class="ud-main-btn" id="notification-ok">OK</button>`;
        }
        modalContent.innerHTML = modalHTML;
        modalContainer.style.display = 'flex';
        modalContainer.style.opacity = '1';
        modalContainer.style.visibility = 'visible';
        const closeModal = () => {
            modalContainer.style.display = 'none';
        };
        setTimeout(() => {
            const closeBtn = modalContainer.querySelector('#notification-close');
            const okBtn = modalContainer.querySelector('#notification-ok');
            if (closeBtn) closeBtn.addEventListener('click', closeModal);
            if (okBtn) okBtn.addEventListener('click', closeModal);
        }, 0);
    }

    function createRandomElement(serviceGroup) {
        const col = document.createElement('div');
        col.className = 'col-2 my-1 service-card';
        const cardDiv = document.createElement('div');
        cardDiv.className = 'card folderService';
        const randomId = `random-${serviceGroup.meta.id}`;
        cardDiv.id = randomId;
        cardDiv.style.position = 'relative';
        col.addEventListener('click', async () => {
            const randomIndex = Math.floor(Math.random() * serviceGroup.accounts.length);
            const randomAccount = serviceGroup.accounts[randomIndex];

            if (!randomAccount.cookies) {
                 const rawPayload = await lazyFetchPayload(randomAccount._lazyRowId);
                 if (!rawPayload) return;
                 // Since it's a group, the rawPayload might contain multiple accounts inside it, 
                 // BUT in Supabase mass-delete mode, each account is uploaded as ONE ROW.
                 // So the payload is just the array of cookies or {cookies: [...]}
                 if (Array.isArray(rawPayload)) randomAccount.cookies = rawPayload;
                 else if (rawPayload.cookies) randomAccount.cookies = rawPayload.cookies;
                 else if (rawPayload.accounts) randomAccount.cookies = rawPayload.accounts[0].cookies;
                 else randomAccount.cookies = [];
            }

            const targetUrl = randomAccount.sourceUrl ? randomAccount.sourceUrl : serviceGroup.meta.url;
            handleServiceClick(targetUrl, randomAccount.cookies, randomAccount.name, randomId);
        });
        const img = document.createElement('img');
        img.src = './icon-random.png';
        img.className = 'logo';
        img.alt = 'Random';
        const p = document.createElement('div');
        p.className = 'menu-text';
        p.textContent = 'Random';
        cardDiv.appendChild(img);
        if (lastInjectedServiceId === randomId) {
            const hourglassIcon = document.createElement('div');
            hourglassIcon.className = 'last-used-icon';
            hourglassIcon.textContent = '⌛';
            Object.assign(hourglassIcon.style, {
                position: 'absolute',
                top: '0px',
                left: '0px'
            });
            cardDiv.appendChild(hourglassIcon);
        }
        col.appendChild(cardDiv);
        return col;
    }

    async function lazyFetchPayload(lazyRowId) {
        const loadingContainer = document.getElementById('loading');
        if (loadingContainer) loadingContainer.style.display = 'flex';
        try {
            const SUPABASE_URL = "https://mujasmmlozswplmtkijr.supabase.co";
            const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im11amFzbW1sb3pzd3BsbXRraWpyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE3MDM4ODgsImV4cCI6MjA3NzI3OTg4OH0.tttyPcoVUtyPLfBm1irS2qYthzt84Yb0OhjxD-tZ4Nw";
            
            const res = await fetch(`${SUPABASE_URL}/rest/v1/gracely_services?id=eq.${lazyRowId}&select=encrypted_payload`, {
                headers: {
                    'apikey': SUPABASE_KEY,
                    'Authorization': `Bearer ${SUPABASE_KEY}`
                }
            });
            if (!res.ok) throw new Error("Gagal mengambil payload: " + res.status);
            const data = await res.json();
            if (!data || data.length === 0) throw new Error("Payload kosong.");

            const encryptedPayloadText = data[0].encrypted_payload;
            if (!encryptedPayloadText) return [];

            const parsedEnc = JSON.parse(encryptedPayloadText);
            const { x_client_sync_meta } = await secureStorage.get(['x_client_sync_meta']);
            const FINAL_KEY = x_client_sync_meta || "Dalam_Nama_Tuhan_Yesus";
            
            const decryptedString = await decryptServiceData(parsedEnc, FINAL_KEY);
            // The uploader encrypted the RAW JSON FILE strings. We'll parse it here.
            // If it's a string from decryptServiceData, it might be an array or object.
            // Wait, decryptServiceData returns an object directly if it succeeds parsing JSON inside.
            return decryptedString;
        } catch (err) {
            console.error(err);
            return null;
        } finally {
            if (loadingContainer) loadingContainer.style.display = 'none';
        }
    }

    function createServiceElement(service) {
        const meta = service.meta;
        const isGroup = meta.isGroup || false;
        
        // COMPOSITE ID CHECK (Backward compatible with old pure ID array)
        const compositeId = String(meta.id) + "_" + String(meta.name).trim();
        const isFavorited = favoriteServices.includes(compositeId) || favoriteServices.includes(String(meta.id));
        const col = document.createElement('div');
        col.className = 'col-2 my-1 service-card';
        const normalizeCat = (c) => c ? c.toLowerCase().replace(/\s/g, '') : 'utilities';
        const categoryString = Array.isArray(meta.category) ? meta.category.map(normalizeCat).join(',') : normalizeCat(meta.category);
        col.dataset.categories = categoryString;
        col.dataset.name = meta.name.toLowerCase();
        if (isFavorited) col.dataset.pinned = 'true';
        const cardDiv = document.createElement('div');
        cardDiv.className = `card ${isGroup ? 'folder' : 'service'}`;
        cardDiv.id = meta.id;
        cardDiv.style.position = 'relative';
        col.addEventListener('click', async () => {
            if (isGroup) {
                renderDetailView(service);
            } else {
                if (!service.cookies) {
                    const rawPayload = await lazyFetchPayload(service._lazyRowId);
                    if (!rawPayload) return;
                    // Usually it's an array of cookies directly, or {cookies: []}
                    if (Array.isArray(rawPayload)) service.cookies = rawPayload;
                    else if (rawPayload.cookies) service.cookies = rawPayload.cookies;
                    else service.cookies = [];
                }
                handleServiceClick(meta.url, service.cookies, meta.name, meta.id);
            }
        });
        col.addEventListener('contextmenu', (e) => createCustomContextMenu(e, service));
        const img = document.createElement('img');
        img.className = 'logo';
        img.alt = meta.name;
        img.src = '';
        cardDiv.appendChild(img);
        const iconUrl = meta.icon;
        if (iconUrl) {
            img.src = iconUrl;
            img.onerror = () => {
                chrome.runtime.sendMessage({
                    action: "getIcon",
                    url: iconUrl
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        return;
                    }
                    if (response && response.status === 'success') {
                        img.src = response.url;
                    }
                });
            };
        }
        const accountCount = isGroup && service.accounts ? service.accounts.length : 0;
        if (isGroup && accountCount > 0) {
            const overlay = document.createElement('div');
            overlay.className = 'overlay';
            overlay.textContent = accountCount;
            cardDiv.appendChild(overlay);
        }
        const p = document.createElement('div');
        p.className = 'menu-text';
        p.textContent = meta.name;
        cardDiv.appendChild(p);
        if (isFavorited) {
            const pinIcon = document.createElement('div');
            pinIcon.className = 'pin-icon';
            pinIcon.textContent = '⭐';
            Object.assign(pinIcon.style, {
                position: 'absolute',
                top: '40px',
                left: '40px',
                zIndex: '10'
            });
            cardDiv.appendChild(pinIcon);
        }
        const isLastInjectedInGroup = isGroup && service.accounts && service.accounts.some(acc => String(acc.id || `${meta.id}-${acc.name}`) == String(lastInjectedServiceId));
        if (String(lastInjectedServiceId) == String(meta.id) || isLastInjectedInGroup) {
            const hourglassIcon = document.createElement('div');
            hourglassIcon.className = 'last-used-icon';
            hourglassIcon.textContent = '⌛';
            Object.assign(hourglassIcon.style, {
                position: 'absolute',
                top: '0px',
                left: '0px',
                zIndex: '11'
            });
            cardDiv.appendChild(hourglassIcon);
        }
        col.appendChild(cardDiv);
        return col;
    }

    function createAccountElement(account, serviceMeta) {
        const col = document.createElement('div');
        col.className = 'col-2 my-1 service-card';
        const accountId = account.id || `${serviceMeta.id}-${account.name}`;
        const cardDiv = document.createElement('div');
        cardDiv.className = 'card folderService';
        cardDiv.id = accountId;
        cardDiv.style.position = 'relative';
        col.addEventListener('click', async () => {
            if (!account.cookies) {
                 const rawPayload = await lazyFetchPayload(account._lazyRowId);
                 if (!rawPayload) return;
                 if (Array.isArray(rawPayload)) account.cookies = rawPayload;
                 else if (rawPayload.cookies) account.cookies = rawPayload.cookies;
                 else if (rawPayload.accounts) account.cookies = rawPayload.accounts[0].cookies;
                 else account.cookies = [];
            }
            const targetUrl = account.sourceUrl ? account.sourceUrl : serviceMeta.url;
            handleServiceClick(targetUrl, account.cookies, account.name, accountId);
        });
        const img = document.createElement('img');
        img.className = 'logo';
        img.alt = account.name;
        img.src = '';
        cardDiv.appendChild(img);
        const iconUrl = serviceMeta.icon;
        if (iconUrl) {
            img.src = iconUrl;
            img.onerror = () => {
                chrome.runtime.sendMessage({
                    action: "getIcon",
                    url: iconUrl
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        return;
                    }
                    if (response && response.status === 'success') {
                        img.src = response.url;
                    }
                });
            };
        }
        const p = document.createElement('div');
        p.className = 'menu-text';
        p.textContent = account.name;
        cardDiv.appendChild(p);
        if (String(lastInjectedServiceId) == String(accountId)) {
            const hourglassIcon = document.createElement('div');
            hourglassIcon.className = 'last-used-icon';
            hourglassIcon.textContent = '⌛';
            Object.assign(hourglassIcon.style, {
                position: 'absolute',
                top: '0px',
                left: '0px'
            });
            cardDiv.appendChild(hourglassIcon);
        }
        col.appendChild(cardDiv);
        return col;
    }

    function handleServiceClick(url, cookies, serviceName, serviceId) {
        if (!url) {
            alert(`URL untuk ${serviceName} kosong.`);
            return;
        }

        // --- LOGIC UPDATE: UNIVERSAL TRACKING ---
        // Kita HAPUS blokir 'isDummy' di sini.
        // Semua request, baik injeksi maupun link biasa, WAJIB lewat background
        // supaya tercatat di 'sessionInjectionHistory' dan bisa dibersihkan saat Safely Logout.

        const loadedContainer = document.getElementById('loaded');
        const loadingContainer = document.getElementById('loading');
        const subfolderView = document.querySelector('.subfolder-view');
        const isPopupMode = window.innerWidth < 800;

        if (loadingContainer) {
            loadingContainer.style.display = 'flex';
            loadingContainer.style.zIndex = '9999';
        }

        // Kirim ke Background (Background akan handle apakah perlu inject atau sekedar buka tab)
        chrome.runtime.sendMessage({
            action: "injectCookies",
            url: url,
            cookies: cookies,
            serviceName: serviceName,
            serviceId: serviceId
        }, (response) => {
            if (chrome.runtime.lastError) {
                alert(`Error: ${chrome.runtime.lastError.message}`);
                if (loadingContainer) loadingContainer.style.display = 'none';
                return;
            }
            if (response.status === 'error') {
                alert(`Gagal: ${response.message}`);
                if (loadingContainer) loadingContainer.style.display = 'none';
                return;
            }

            // SUKSES

            // CRITICAL FIX: Always update global variable so UI is correct if user navigates back or reopens
            lastInjectedServiceId = String(serviceId);
            // AND SAVE TO STORAGE for persistence across sessions
            secureStorage.set({
                lastInjectedServiceId: String(serviceId)
            });

            if (isPopupMode) {
                window.close();
            } else {
                if (loadingContainer) loadingContainer.style.display = 'none';
                // Update UI hourglass
                if (currentServiceGroup) {
                    renderDetailView(currentServiceGroup);
                } else {
                    displayMainView(allServices);
                }
            }
        });
    }

    function setCategoryViewState(isHidden) {
        filtersContainer.classList.toggle('hidden', isHidden);
        toggleFiltersButton.classList.toggle('rotated', !isHidden);
    }

    function applyTheme(theme) {
        document.body.classList.toggle('dark-theme', theme === 'dark');
        logoImage.src = theme === 'light' ? './logo_light.png' : './logo.png';
        themeLightButton.classList.toggle('d-none', theme === 'light');
        themeDarkButton.classList.toggle('d-none', theme !== 'light');
        localStorage.setItem('theme', theme);
    }

    function filterAndSearch() {
        const searchTerm = appSearch.value.toLowerCase().trim();
        const activeCategories = [...document.querySelectorAll('.category-filter.active')].map(btn => btn.dataset.category).filter(cat => cat !== 'all');
        const isAllActive = document.querySelector('.category-filter[data-category="all"]').classList.contains('active');
        
        // --- 1. Top-Level Filter (Main Grid) ---
        document.querySelectorAll('#loaded > .service-card').forEach(card => {
            const cardId = card.querySelector('.card').id;
            const nameMatch = card.dataset.name.toLowerCase().includes(searchTerm);
            
            // Deep search into accounts (Subfolders)
            let deepMatch = false;
            let targetServiceGroup = allServices.find(s => String(s.meta.id) === String(cardId));
            
            if (targetServiceGroup && targetServiceGroup.meta.isGroup && targetServiceGroup.accounts) {
                 deepMatch = targetServiceGroup.accounts.some(acc => acc.name.toLowerCase().includes(searchTerm));
            }

            let categoryMatch = false;
            if (isAllActive || activeCategories.length === 0) {
                categoryMatch = true;
            } else {
                const cardCategoriesString = card.dataset.categories || '';
                const cardCategories = cardCategoriesString.split(',');
                categoryMatch = cardCategories.some(cardCat => activeCategories.includes(cardCat));
            }
            card.style.display = ((nameMatch || deepMatch) && categoryMatch) ? '' : 'none';
        });

        // --- 2. Sub-folder Deep Filtering ---
        // Jika kita SEDANG berada di dalam subfolder, filter kartu-kartu di dalamnya!
        const subfolderView = mainContainer.querySelector('.subfolder-view');
        if (subfolderView) {
             subfolderView.querySelectorAll('.service-card').forEach(subCard => {
                  const cardEl = subCard.querySelector('.card');
                  // Kartu "Random" disembunyikan jika sedang mencari
                  if (cardEl && cardEl.id && cardEl.id.startsWith('random-')) {
                       subCard.style.display = searchTerm === '' ? '' : 'none'; 
                       return;
                  }
                  
                  // Kartu Akun Biasa
                  const accTextEl = cardEl.querySelector('.menu-text');
                  if (accTextEl) {
                       const accName = accTextEl.textContent.toLowerCase();
                       subCard.style.display = accName.includes(searchTerm) ? '' : 'none';
                  }
             });
        }
    }
    // Listener removed: Instant Popup feature reverted.
    function showUpdateModal(versionControl) {
        // Fallback HTML if config is stale
        const defaultHtml = "<div class='notificationModal-content'><i class='fa fa-times close-icon' id='notification-close'></i><h2 style='margin: 0 0 16px 0; text-align: center; color: #2c3e50; font-size: 22px; border-bottom: 3px solid #333333; padding-bottom: 8px;'>Update Required</h2><div style='background: #f8f9fa; padding: 12px; border-radius: 8px; margin-bottom: 10px;'><p style='margin: 6px 0; font-size: 14px;'> Versi <b>Gracely Extension</b> dan <b>Gracely Guard</b> Anda sudah usang.</p></div><div style='border: 2px dashed #666666; padding: 8px 10px; border-radius: 8px; background: #f5f5f5; margin-bottom: 12px;'><p style='margin: 0; text-align: center; color: #333333; font-size: 13px;'><b>Please Update Gracely Extension</b>😊🙏</p></div><div style='border: 2px dashed #666666; padding: 8px 10px; border-radius: 8px; background: #f5f5f5; margin-bottom: 12px;'><p style='margin: 0; text-align: center; color: #333333; font-size: 13px;'><b>Please Update Gracely Guard</b>😊🙏</p></div><div style='display:none;'><span id='update-countdown'>30</span></div><button class='ud-main-btn' id='notification-ok'>OK Lae</button></div>";

        const modalHtml = versionControl.updateMessageHTML || defaultHtml;

        // Create container
        const modal = document.createElement('div');
        modal.className = 'notificationModal'; // Reuse existing class for styling

        // FORCE VISIBILITY & OVERLAY
        modal.style.display = 'flex';
        modal.style.opacity = '1';
        modal.style.visibility = 'visible';
        modal.style.zIndex = '99999'; // Top of everything
        modal.style.backgroundColor = 'rgba(0,0,0,0.7)'; // Dark Overlay (Focus Mode)

        modal.innerHTML = modalHtml;
        document.body.appendChild(modal);

        const countdownEl = document.getElementById('update-countdown');
        const okBtn = document.getElementById('notification-ok');
        const closeBtn = document.getElementById('notification-close');
        const targetUrl = versionControl.updateUrl || "https://gracely011.github.io/hai/dashboard.html";

        // --- TRIGGER BACKGROUND COUNTDOWN (PERSISTENT) ---
        chrome.runtime.sendMessage({
            action: "triggerUpdateCountdown",
            targetUrl: targetUrl
        });

        // Visual Countdown only (Popup side)
        let timeLeft = 30;
        const timer = setInterval(() => {
            timeLeft--;
            if (countdownEl) countdownEl.innerText = timeLeft;

            // Detik ke-30 (Habis): Close Popup (Background handles disabling)
            if (timeLeft <= 0) {
                clearInterval(timer);
                window.close(); // Close popup
            }
        }, 1000);

        if (okBtn) {
            okBtn.onclick = () => {
                window.open(targetUrl, '_blank');
                window.close();
            };
        }
        if (closeBtn) {
            closeBtn.onclick = () => {
                window.close();
            };
        }
    }

    main();
});