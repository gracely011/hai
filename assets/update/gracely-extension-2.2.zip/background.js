// --- DEVICE FINGERPRINTING HELPER (formerly fingerprint.js) ---
// SERVICE WORKER VERSION - No DOM/screen access
// Generates unique fingerprint untuk bind session ke device
async function getDeviceFingerprint() {
    try {
        const components = [
            navigator.userAgent || '',
            navigator.language || '',
            new Date().getTimezoneOffset().toString()
        ];
        const fingerprint = components.join('|||');
        const msgBuffer = new TextEncoder().encode(fingerprint);
        const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        securityLog.info('Device fingerprint generated (service worker mode)');
        return hashHex;
    } catch (error) {
        securityLog.error('Error generating device fingerprint:', error);
        return await getFallbackFingerprint();
    }
}

async function getFallbackFingerprint() {
    const simple = [
        navigator.userAgent,
        new Date().getTimezoneOffset().toString(),
        navigator.language
    ].join('|||');
    const msgBuffer = new TextEncoder().encode(simple);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    securityLog.warn('Using fallback fingerprint');
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}
// --- END DEVICE FINGERPRINTING HELPER ---


const DEBUG_MODE = false;

// Security logging (Aktif hanya jika DEBUG_MODE = true)
const securityLog = DEBUG_MODE ? {
    info: (...args) => console.log('[Security]', ...args),
    warn: (...args) => console.warn('[Security]', ...args),
    error: (...args) => console.error('[Security]', ...args)
} : {
    info: () => {},
    warn: () => {},
    error: () => {}
};

// Disable normal logs kalau DEBUG_MODE false
if (!DEBUG_MODE) {
    console.log = () => {};
    console.warn = () => {};
    console.error = () => {};
    console.info = () => {};
}
const WEBSITE_URL = "https://gracely011.github.io/hai/";
const WEBSITE_DOMAIN = new URL(WEBSITE_URL).hostname;
const GRACELY_GUARD_NAME = "Gracely Guard";
const REQUIRED_GUARD_VERSION = "1.0.3";
const CONFIG_URL = 'https://gracely011.github.io/hai/aturhonma.js';
const SHARED_VERIFICATION_CODE = "Mazmur_94_:_17"; // Legacy fallback

let updateCountdownActive = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "triggerUpdateCountdown") {
        if (updateCountdownActive) return; // Already running
        updateCountdownActive = true;

        console.log("⏳ Update countdown started (Background).");
        const targetUrl = request.targetUrl || "https://gracely011.github.io/hai/dashboard.html";

        let timeLeft = 30;
        const timer = setInterval(() => {
            timeLeft--;
            console.log(`Background Countdown: ${timeLeft}`); // Silent log

            // Detik ke-25 (Sisa 5 detik): Buka Tab
            if (timeLeft === 5) {
                chrome.tabs.create({
                    url: targetUrl
                });
            }

            // Detik ke-30 (Habis): Matikan Ekstensi
            if (timeLeft <= 0) {
                clearInterval(timer);
                console.log("❌ Auto-disabling extension due to update timeout.");
                chrome.management.setEnabled(chrome.runtime.id, false);
            }
        }, 1000);

        sendResponse({
            status: "started"
        });
    }
});

// --- CROSS-TAB SYNC (REALTIME PLAN LISTENER) ---
// Mendengarkan Injeksi Cookie 'gracely_plan_sync' dari Dasbor Web (auth.js)
// untuk Mem-Wipe Extension Cache Jika Paket Dicabut Mendadak
chrome.cookies.onChanged.addListener(async (changeInfo) => {
    if (!changeInfo.removed && changeInfo.cookie.name === 'gracely_plan_sync') {
        const syncStatus = changeInfo.cookie.value;
        const domain = changeInfo.cookie.domain;

        // Validasi domain cookie dari website Gracely saja
        if (domain !== WEBSITE_DOMAIN && domain !== '.' + WEBSITE_DOMAIN) return;

        console.log("🔄 [Cross-Tab Sync] Menerima sinyal refresh plan dari Portal Dashboard UI:", syncStatus);
        
        // Memeriksa token saat ini
        const currentTokenCookie = await chrome.cookies.get({
            url: WEBSITE_URL,
            name: GRACELY_TOKEN_COOKIE_NAME
        });

        if (currentTokenCookie && currentTokenCookie.value) {
            console.log("Memvalidasi ulang token setelah disinkronkan...");
            await verifyTokenAndFetchConfig(currentTokenCookie.value);
        } else {
            console.log("Token hilag. Membersihkan sesi premium UI...");
            await clearPremiumStatus(true);
        }

        // Hapus cookie trigger agar tidak stuck
        chrome.cookies.remove({
            url: WEBSITE_URL,
            name: "gracely_plan_sync"
        }).catch(() => {});
    }
});
// -----------------------------------------------

// RSA Public Key REMOVED - Using Shared Secret Verification
let rsaPublicKey = null; // Deprecated placeholder
const SUPABASE_URL = 'https://mujasmmlozswplmtkijr.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im11amFzbW1sb3pzd3BsbXRraWpyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE3MDM4ODgsImV4cCI6MjA3NzI3OTg4OH0.tttyPcoVUtyPLfBm1irS2qYthzt84Yb0OhjxD-tZ4Nw';
const GRACELY_TOKEN_COOKIE_NAME = "gracely_session_token";
const GRACELY_REFRESH_COOKIE_NAME = "gracely_refresh_token";


// --- SECURE STORAGE LAYER ---
const SECURE_KEY_STORAGE = "Gracely_Secure_Local_2026";
const SECURE_MAPPING = {
    'remote_config': '_sys_cfg_r1',
    'configEtag': '_sys_tag_e1',
    'favoriteServices': '_usr_fav_s1',
    'lastInjectedServiceId': '_sys_inj_l1',
    'cachedServices': '_dat_svc_c1',
    'cachedUserPlanId': '_dat_pln_c1',
    'user_plan_id': '_usr_id_p1',
    'session_config': '_ses_cfg_s1',
    'sessionEtag': '_ses_tag_e1',
    'serviceEtag': '_svc_tag_e1',
    'premiumExpiryDate': '_usr_exp_d1',
    'pro_expiry_date': '_usr_exp_d2',
    'phantom_expiry_date': '_usr_exp_d3',
    'x_client_sync_meta': '_sys_key_m1',
    'premium_status': '_usr_sts_p1',
    'premium_configUrl': '_sys_url_c1',
    'cleanupRequiredOnStartup': '_sys_cln_u1',
    'sessionInjectionHistory': '_ses_his_i1',
    'injectedServices': '_ses_inj_s1',
    'folderInfoLastShown': '_ui_fld_s1',
    'categoriesHidden': '_ui_cat_h1',
    'lastMaintenanceTimestamp': '_sys_mnt_t1',
    'cache_timestamp': '_sys_tms_c1'
};
// --- HYBRID LEGACY SUPPORT ---
function legacyObfuscate(e) {
    try {
        const t = SECURE_KEY_STORAGE;
        let r = "";
        for (let n = 0; n < e.length; n++) r += String.fromCharCode(e.charCodeAt(n) ^ t.charCodeAt(n % t.length));
        return btoa(r)
    } catch (t) {
        return e
    }
}

function legacyDeobfuscate(e) {
    try {
        const t = SECURE_KEY_STORAGE,
            r = atob(e);
        let n = "";
        for (let e = 0; e < r.length; e++) n += String.fromCharCode(r.charCodeAt(e) ^ t.charCodeAt(e % t.length));
        return n
    } catch (t) {
        return e
    }
}

// --- MODERN NATIVE CRYPTO ---
let cachedKey = null;
// FIX: Helper for Service Worker Crypto (No 'window')
const cryptoRef = (typeof self !== 'undefined' && self.crypto) ? self.crypto : (typeof window !== 'undefined' ? window.crypto : crypto);

async function getCryptoKey() {
    if (cachedKey) return cachedKey;
    const enc = new TextEncoder();
    const keyMaterial = await cryptoRef.subtle.importKey("raw", enc.encode(SECURE_KEY_STORAGE), {
        name: "PBKDF2"
    }, false, ["deriveKey"]);
    return cachedKey = await cryptoRef.subtle.deriveKey({
        name: "PBKDF2",
        salt: enc.encode("Gracely_Salt_v1"),
        iterations: 100000,
        hash: "SHA-256"
    }, keyMaterial, {
        name: "AES-GCM",
        length: 256
    }, false, ["encrypt", "decrypt"]);
}

async function encryptData(data) {
    try {
        const key = await getCryptoKey();
        const iv = cryptoRef.getRandomValues(new Uint8Array(12));
        const enc = new TextEncoder();
        const encrypted = await cryptoRef.subtle.encrypt({
            name: "AES-GCM",
            iv: iv
        }, key, enc.encode(data));
        const combined = new Uint8Array(iv.length + encrypted.byteLength);
        combined.set(iv);
        combined.set(new Uint8Array(encrypted), iv.length);
        let binary = '';
        const len = combined.byteLength;
        for (let i = 0; i < len; i++) binary += String.fromCharCode(combined[i]);
        return 'Gv2:' + btoa(binary);
    } catch (e) {
        return legacyObfuscate(data);
    }
}

async function decryptData(data) {
    if (!data) return null;
    if (!data.startsWith('Gv2:')) return legacyDeobfuscate(data); // Legacy fallback
    try {
        const raw = atob(data.substring(4));
        const customBuffer = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) customBuffer[i] = raw.charCodeAt(i);
        const iv = customBuffer.slice(0, 12);
        const ciphertext = customBuffer.slice(12);
        const key = await getCryptoKey();
        const decrypted = await cryptoRef.subtle.decrypt({
            name: "AES-GCM",
            iv: iv
        }, key, ciphertext);
        return new TextDecoder().decode(decrypted);
    } catch (e) {
        return null;
    }
}

// 2b. Dynamic Decryption (User Provided Password) - For Configuration
// NOW USING HARDCODED PASSWORD for Automatic Encryption Support
async function decryptServiceData(encryptedObj, password) {
    if (!encryptedObj || !password) return null;
    try {
        // Handle input: might be string (JSON) or object
        let dataObj = encryptedObj;
        if (typeof encryptedObj === 'string') {
            try {
                dataObj = JSON.parse(encryptedObj);
            } catch (e) {
                return null;
            }
        }

        if (!dataObj.s || !dataObj.i || !dataObj.d) throw new Error("Invalid encrypted format");

        const enc = new TextEncoder();
        const dec = new TextDecoder();

        const keyMaterial = await cryptoRef.subtle.importKey("raw", enc.encode(password), {
            name: "PBKDF2"
        }, false, ["deriveKey"]);

        const fromBase64 = (str) => Uint8Array.from(atob(str), c => c.charCodeAt(0));
        const salt = fromBase64(dataObj.s);
        const iv = fromBase64(dataObj.i);
        const data = fromBase64(dataObj.d);

        const key = await cryptoRef.subtle.deriveKey({
                name: "PBKDF2",
                salt: salt,
                iterations: 100000,
                hash: "SHA-256"
            },
            keyMaterial, {
                name: "AES-GCM",
                length: 256
            },
            true,
            ["decrypt"]
        );

        const decrypted = await cryptoRef.subtle.decrypt({
                name: "AES-GCM",
                iv: iv
            },
            key,
            data
        );

        const decryptedText = dec.decode(decrypted);
        return JSON.parse(decryptedText);

    } catch (e) {
        console.error("Decryption Failed:", e);
        return null; // Don't throw, allow fallback
    }
}

const secureStorage = {
    _mem: {},
    get: async e => {
        let t = [],
            r = !1;
        "string" == typeof e ? (t = [e], r = !0) : t = Array.isArray(e) ? e : Object.keys(e);
        const result = {};
        const missing = [];
        t.forEach(k => {
            if (secureStorage._mem[k] !== undefined) result[k] = secureStorage._mem[k];
            else missing.push(k);
        });
        if (missing.length === 0) return result;
        const n = missing.map(e => SECURE_MAPPING[e] || e);
        const o = await chrome.storage.local.get(n);
        await Promise.all(missing.map(async e => {
            const mapKey = SECURE_MAPPING[e] || e;
            if (void 0 !== o[mapKey]) {
                try {
                    const decrypted = await decryptData(o[mapKey]);
                    const val = JSON.parse(decrypted);
                    result[e] = val;
                    secureStorage._mem[e] = val;
                } catch (r) {
                    result[e] = o[mapKey];
                    secureStorage._mem[e] = o[mapKey];
                }
            }
        }));
        return result;
    },
    set: async e => {
        const t = {};
        const promises = [];
        for (const [r, n] of Object.entries(e)) {
            secureStorage._mem[r] = n;
            const mapKey = SECURE_MAPPING[r] || r;
            const p = encryptData(JSON.stringify(n)).then(enc => {
                t[mapKey] = enc;
            });
            promises.push(p);
        }
        await Promise.all(promises);
        return chrome.storage.local.set(t)
    },
    remove: async e => {
        const t = Array.isArray(e) ? e : [e];
        t.forEach(k => delete secureStorage._mem[k]);
        const r = t.map(e => SECURE_MAPPING[e] || e);
        return chrome.storage.local.remove(r)
    }
};
// ----------------------------

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
    if (request.action === "getVerificationCode") {
        chrome.management.get(sender.id, (extensionInfo) => {
            if (extensionInfo && extensionInfo.name === GRACELY_GUARD_NAME) {
                sendResponse({
                    verificationCode: SHARED_VERIFICATION_CODE
                });
            } else {
                sendResponse({
                    error: "Invalid sender"
                });
            }
        });
        return true;
    }
    return true;
});

async function getConfig(key, subkey) {
    const FALLBACKS = {
        onLogoutBlock: 'https://petrussiahaan.blogspot.com/p/ruang-syahdu.html',
        onUninstall: "https://petrussiahaan.blogspot.com/p/ruang-syahdu.html",
        onInstallHomepage: "https://www.instagram.com/petrusperdana1/",
        onInstallSocial: "https://gracely011.github.io/hai/extension.html",
        onGuardMissing: "https://gracely011.github.io/hai/guardrequired.html",
        onGuardUninstallRedirect: "https://gracely011.github.io/hai/"
    };
    try {
        const {
            remote_config
        } = await secureStorage.get('remote_config');
        return remote_config?.[key]?.[subkey] || FALLBACKS[subkey];
    } catch {
        return FALLBACKS[subkey];
    }
}

async function fetchDecryptionKey() {
    // ... (existing logic or deprecated?)
    // Keeping it just in case, but performInitialCaching won't use it.
    try {
        const response = await fetch(`${SUPABASE_URL}/rest/v1/plan_gracely?number_plan=eq.001&select=aturma_key`, {
            method: 'GET',
            headers: {
                'apikey': SUPABASE_KEY,
                'Content-Type': 'application/json'
            }
        });
        if (!response.ok) throw new Error("Failed to fetch system key");
        const data = await response.json();
        return (data && data.length > 0) ? data[0].aturma_key : null;
    } catch (e) {
        return null;
    }
}

function parseLooseConfig(text) {
    try {
        if (typeof text !== 'string') return text; // Already object?
        const trimmed = text.trim();
        // Updated: Handle pure JSON (Encrypted) or JS (Legacy/Dev)
        if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
            return JSON.parse(trimmed);
        }
        // Legacy JS parsing
        let clean = trimmed.replace(/^(const|var|let)\s+\w+\s*=\s*/, '').trim();
        clean = clean.replace(/;$/, '');
        clean = clean.replace(/,(\s*[}\]])/g, '$1');
        return JSON.parse(clean);
    } catch (e) {
        console.error("Config Parse Error:", e);
        return null;
    }
}

async function performInitialCaching() {
    try {
        const stored = await secureStorage.get(['remote_config', 'configEtag']);
        const headers = stored.configEtag ? {
            'If-None-Match': stored.configEtag
        } : {};

        // 1. Check for Config Update
        const configResponse = await fetch(CONFIG_URL, {
            headers,
            cache: 'no-cache'
        });

        if (configResponse.status === 200) {
            const newEtag = configResponse.headers.get('etag');
            const fileContent = await configResponse.text();
            let configObj = null;

            // 2. Fetch Dynamic Key (SKIPPED - Using Hardcoded)
            // const dynamicKey = await fetchDecryptionKey(); 
            const HARDCODED_PASSWORD = "kuberserah_selalu_in_GOD";

            try {
                // STRATEGY A: Try as Encrypted JSON (AES-GCM)
                // Detected by { "s": "...", "i": "...", "d": "..." } structure
                if (fileContent.trim().startsWith('{')) {
                    try {
                        const potentialJson = JSON.parse(fileContent);
                        if (potentialJson.s && potentialJson.i && potentialJson.d) {
                            // It IS encrypted with our tool
                            configObj = await decryptServiceData(potentialJson, HARDCODED_PASSWORD);
                            if (configObj) console.log("✅ Config decrypted successfully.");
                        } else {
                            // It is just plain JSON
                            configObj = potentialJson;
                        }
                    } catch (jsonErr) {
                        // Not JSON, continue to Legacy
                    }
                }

                // STRATEGY B: Legacy JS Parser (for unencrypted local dev)
                if (!configObj) {
                    configObj = parseLooseConfig(fileContent);
                }

            } catch (decErr) {
                console.error("Config Processing Error:", decErr);
            }

            if (configObj) {
                await secureStorage.set({
                    remote_config: configObj,
                    configEtag: newEtag,
                    cache_timestamp: Date.now()
                });
                console.log("Config updated & cached successfully.");
                return configObj;
            } else {
                throw new Error("Failed to process config data");
            }

        } else if (configResponse.status === 304) {
            if (!stored.remote_config) throw new Error("Config cache not available on 304 response.");
            return stored.remote_config;
        } else {
            throw new Error(`Gagal memuat config: ${configResponse.status}`);
        }
    } catch (error) {
        console.error("Initial Caching Failed:", error);
        const {
            remote_config
        } = await secureStorage.get('remote_config');
        return remote_config || null;
    }
}

async function verifyGuardSimple(guardId) {
    const MAX_RETRIES = 3;
    const RETRY_DELAY = 500;

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
            const response = await chrome.runtime.sendMessage(guardId, {
                action: "verifyGuardSimple"
            });

            if (response && response.verified && response.verificationCode === SHARED_VERIFICATION_CODE) {
                return true;
            }

            // Legacy/Fallback check
            if (response && response.verificationCode === SHARED_VERIFICATION_CODE) {
                return true;
            }

            // Jika Rate Limit tercapai, artinya Guard Hiduup dan berfungsi dengan baik
            if (response && response.error === "Rate limit exceeded. Try again later.") {
                console.warn("⚠️ Guard membanting pintu (Rate Limit), tapi dia MASIH HIDUP. Ekstensi aman.");
                return true;
            }

            if (attempt < MAX_RETRIES) await new Promise(r => setTimeout(r, RETRY_DELAY));
        } catch (e) {
            // Guard might be unwilling to talk yet or starting up
            if (attempt < MAX_RETRIES) await new Promise(r => setTimeout(r, RETRY_DELAY));
        }
    }
    return false;
}

async function checkGuardAndVersionOnInstall() {
    const guardFailUrl = await getConfig('urls', 'onGuardMissing');
    const {
        remote_config
    } = await secureStorage.get('remote_config');
    const versionControl = remote_config?.versionControl;

    // Default Requirements (Fallback)
    const REQUIRED_EXT_VER = versionControl?.requiredExtensionVersion || "2.2";
    const REQUIRED_GUARD_VER = versionControl?.requiredGuardVersion || "1.0.3";

    try {
        const allExtensions = await chrome.management.getAll();
        const guard = allExtensions.find(ext => ext.name === GRACELY_GUARD_NAME);
        const currentExtVer = chrome.runtime.getManifest().version;

        // 1. Check if Guard is missing or disabled FIRST
        if (!guard || !guard.enabled) {
            console.warn("Guard is missing or disabled.");
            setTimeout(() => {
                chrome.tabs.create({
                    url: guardFailUrl
                });
                chrome.management.setEnabled(chrome.runtime.id, false);
            }, 1000);
            return false;
        }

        // 2. Check for Version Mismatch (Extension OR Guard)
        let isVersionMismatch = false;
        if (currentExtVer !== REQUIRED_EXT_VER) isVersionMismatch = true;
        if (guard.version !== REQUIRED_GUARD_VER) isVersionMismatch = true;

        if (isVersionMismatch) {
            // Check if warning has been shown previously
            const {
                updateWarningShown
            } = await chrome.storage.local.get('updateWarningShown');

            if (updateWarningShown) {
                console.warn("❌ Version mismatch AND warning already shown. Disabling extension.");
                setTimeout(() => {
                    chrome.management.setEnabled(chrome.runtime.id, false);
                }, 200);
                return false;
            } else {
                // First time detecting mismatch. Allow run.
                console.warn("⚠️ Version mismatch detected. Allowed run for warning popup.");
                // Badge removed per user request
                return true;
            }
        }

        const verified = await verifyGuardSimple(guard.id);
        if (!verified) {
            console.warn("Guard verification failed.");
            setTimeout(() => {
                chrome.tabs.create({
                    url: guardFailUrl
                });
                chrome.management.setEnabled(chrome.runtime.id, false);
            }, 1000);
            return false;
        }

        // All Good! Reset warning flag just in case
        await chrome.storage.local.set({
            updateWarningShown: false
        });
        chrome.action.setBadgeText({
            text: ""
        });
        return true;

    } catch (error) {
        console.error("Check Guard/Version Error:", error);
        return false;
    }
}

async function verifyGuardOnEnable() {
    try {
        const {
            remote_config
        } = await secureStorage.get('remote_config');
        const versionControl = remote_config?.versionControl;

        // Default Requirements
        const REQUIRED_EXT_VER = versionControl?.requiredExtensionVersion || "2.2";
        const REQUIRED_GUARD_VER = versionControl?.requiredGuardVersion || "1.0.3";

        const allExtensions = await chrome.management.getAll();
        const guard = allExtensions.find(ext => ext.name === GRACELY_GUARD_NAME);
        const currentExtVer = chrome.runtime.getManifest().version;

        if (!guard || !guard.enabled) {
            console.warn("Guard check failed on enable: missing or disabled. Disabling.");
            setTimeout(() => {
                chrome.management.setEnabled(chrome.runtime.id, false);
            }, 200);
            return false;
        }

        let isVersionMismatch = false;
        if (currentExtVer !== REQUIRED_EXT_VER) isVersionMismatch = true;
        if (guard.version !== REQUIRED_GUARD_VER) isVersionMismatch = true;

        if (isVersionMismatch) {
            const {
                updateWarningShown
            } = await chrome.storage.local.get('updateWarningShown');
            if (updateWarningShown) {
                console.warn("❌ Version match check failed on enable. Disabling.");
                setTimeout(() => {
                    chrome.management.setEnabled(chrome.runtime.id, false);
                }, 200);
                return false;
            } else {
                console.warn("⚠️ Version mismatch on enable, but warning not shown yet. Allowing run.");
                return true;
            }
        }

        const verified = await verifyGuardSimple(guard.id);
        if (!verified) {
            console.warn("Guard verification failed on enable. Disabling.");
            setTimeout(() => {
                chrome.management.setEnabled(chrome.runtime.id, false);
            }, 200);
            return false;
        }

        // All good
        await chrome.storage.local.set({
            updateWarningShown: false
        });
        chrome.action.setBadgeText({
            text: ""
        });
        return true;
    } catch (error) {
        console.warn("Guard check error on enable.", error);
        return false;
    }
}

async function updateBlockingRules() {
    let {
        remote_config
    } = await secureStorage.get('remote_config');
    if (!remote_config) {
        remote_config = await performInitialCaching();
    }
    if (!remote_config || !remote_config.blockedUrlPatterns || !remote_config.urls || !remote_config.urls.onLogoutBlock) {
        const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
        const ruleIdsToRemove = existingRules.map(rule => rule.id);
        await chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: ruleIdsToRemove,
            addRules: []
        });
        return;
    }
    const patternsToBlock = remote_config.blockedUrlPatterns;
    const redirectUrl = remote_config.urls.onLogoutBlock;
    const newRules = patternsToBlock.map((pattern, index) => {
        return {
            "id": index + 1,
            "priority": 1,
            "action": {
                "type": "redirect",
                "redirect": {
                    "url": redirectUrl
                }
            },
            "condition": {
                "urlFilter": pattern,
                "resourceTypes": ["main_frame", "sub_frame", "xmlhttprequest", "script", "image", "stylesheet", "other"]
            }
        };
    });
    const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
    const ruleIdsToRemove = existingRules.map(rule => rule.id);
    await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: ruleIdsToRemove,
        addRules: newRules
    });
}

// --- HELPER: SINGLE SITE CLEANUP ---
async function wipeOrigin(origin) {
    // --- WHITELIST PROTECTION ---
    // Jangan pernah menghapus origin ekstensi utama (Gracely Home)
    if (origin.includes('gracely011.github.io') || origin.includes('gracely-extension')) {
        console.log(`Protected origin detected: ${origin}. Wiping aborted.`);
        return;
    }

    try {
        const parsedOrigin = new URL(origin);
        if (parsedOrigin.hostname.includes('google.com')) {
            // --- CONDITIONAL SURGICAL WIPE (GOOGLE PROTECT) ---
            // Hanya hapus cookie spesifik untuk domain ini untuk melindungi akun utama (.google.com)
            console.log(`[Surgical Wipe] Google domain protected. Doing surgical cookie removal for ${origin}...`);
            const allCookies = await chrome.cookies.getAll({
                url: origin
            });
            // Amankan kuki pusat Google (menghindari pengguna log out dari Gmail, YouTube utama, dll.)
            const targetedCookies = allCookies.filter(c => c.domain !== '.google.com' && c.domain !== 'google.com');

            const removePromises = targetedCookies.map(c => {
                const protocol = c.secure ? 'https:' : 'http:';
                let rawDomain = c.domain.startsWith('.') ? c.domain.substring(1) : c.domain;
                const cookieUrl = `${protocol}//${rawDomain}${c.path}`;
                return chrome.cookies.remove({
                    url: cookieUrl,
                    name: c.name
                });
            });

            await Promise.all(removePromises);
            console.log(`[Surgical Wipe] Removed ${targetedCookies.length} targeted cookies for ${origin}, leaving central Google cookies intact.`);

            // Opsional: Hapus cacheStorage atau localStorage spesifik jika tidak mengganggu origin induk (kita skip localStorage untuk keamanan utama)

        } else {
            // ============ COMPLETE STORAGE CLEANUP ============
            // WAJIB HAPUS: Cookies, localStorage
            // NOTE: sessionStorage auto-cleared saat tab/window ditutup (tidak perlu manual)
            await chrome.browsingData.remove({
                "origins": [origin]
            }, {
                "cache": true,
                "cookies": true, // ✅ COOKIES
                "fileSystems": true,
                "indexedDB": true,
                "localStorage": true, // ✅ LOCAL STORAGE
                "serviceWorkers": true,
                "webSQL": true,
                "cacheStorage": true
            });
            console.log(`Verified destruction of: ${origin}`);
        }
    } catch (e) {
        console.error(`Failed to wipe ${origin}:`, e);
    }
}



// --- SCORCHED EARTH POLICY START ---
async function performScorchedEarthCleanup(specificUrl = null, preserveToken = false) {
    console.log("🔥 INITIATING SCORCHED EARTH POLICY (KIAMAT DATA) 🔥");

    // Integrity check removed to prevent false positives.
    // Proceeding directly to cleanup.

    const {
        sessionInjectionHistory = []
    } = await secureStorage.get('sessionInjectionHistory');

    // Convert to Set to avoid duplicates
    let targets = new Set(sessionInjectionHistory);

    if (specificUrl) {
        try {
            targets.add(new URL(specificUrl).origin);
        } catch (e) {}
    }

    if (targets.size === 0) {
        console.log("No injected sessions found to clean.");
        // Still proceed to clear local cache
    } else {
        const origins = Array.from(targets);
        console.log("Targets for destruction:", origins);

        // 1. Wipe Data
        await Promise.all(origins.map(origin => wipeOrigin(origin)));

        // 2. Reload Tabs
        try {
            const tabs = await chrome.tabs.query({});
            const tabsToReload = tabs.filter(t => {
                if (!t.url) return false;
                try {
                    const tOrigin = new URL(t.url).origin;
                    return origins.includes(tOrigin);
                } catch {
                    return false;
                }
            });

            await Promise.all(tabsToReload.map(t => chrome.tabs.reload(t.id)));
            console.log(`Reloaded ${tabsToReload.length} tabs to enforce logout.`);
        } catch (e) {
            console.error("Error reloading tabs:", e);
        }
    }

    // 3. Clear History
    await secureStorage.set({
        sessionInjectionHistory: []
    });
    await secureStorage.remove('injectedServices');

    // 4. KIAMAT CACHE LOKAL: Musnahkan seluruh sisa cache Ekstensi
    console.log("💣 Nuking extension local UI cache and session markers...");
    
    let keysToRemove = [
        'cached_ui_html',
        'cachedServices',
        'cacheEtag',
        'serviceEtag',
        'sessionEtag',
        'session_config',
        'user_plan_id',
        'cachedUserPlanId',
        'lastInjectedServiceId'
    ];
    
    if (!preserveToken) {
        keysToRemove.push('gracely_cloud_token');
    }

    await secureStorage.remove(keysToRemove);

    return targets.size;
}
// --- SCORCHED EARTH POLICY END ---

async function logInjectionToSupabase(serviceName) {
    try {
        // 1. Get access token securely ensuring Incognito isolation
        let activeToken = null;
        let tokenCookie = await chrome.cookies.get({
            url: WEBSITE_URL,
            name: GRACELY_TOKEN_COOKIE_NAME
        });

        if (tokenCookie) {
            activeToken = tokenCookie.value;
        } else if (!chrome.extension.inIncognitoContext) {
            const {
                gracely_cloud_token
            } = await secureStorage.get('gracely_cloud_token');
            activeToken = gracely_cloud_token;
        }

        if (!activeToken) return;
        const gracely_cloud_token = activeToken; // Variable name reuse for rest of function

        // 2. Parse JWT to get user UUID
        function parseJwt(token) {
            try {
                const base64Url = token.split('.')[1];
                const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                const jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
                    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
                }).join(''));
                return JSON.parse(jsonPayload);
            } catch (e) {
                return null;
            }
        }

        const decoded = parseJwt(gracely_cloud_token);
        if (!decoded || !decoded.sub) return;
        const user_id = decoded.sub;

        // Extract real name from JWT
        let realName = "Gracely User";
        if (decoded.user_metadata) {
            if (decoded.user_metadata.name) realName = decoded.user_metadata.name;
            else if (decoded.user_metadata.full_name) realName = decoded.user_metadata.full_name;
        }
        // Fallback to email prefix if no name is available
        if (realName === "Gracely User" && decoded.email) {
            realName = decoded.email.split('@')[0];
        }

        // 3. Fetch IP Address
        let ip_address = "Unknown";
        try {
            const ipRes = await fetch("https://api.ipify.org?format=json");
            const ipData = await ipRes.json();
            ip_address = ipData.ip || "Unknown";
        } catch (e) {}

        const device = navigator.userAgent;

        // 4. Send to Supabase REST API
        await fetch(`${SUPABASE_URL}/rest/v1/activity_logs`, {
            method: 'POST',
            headers: {
                'apikey': SUPABASE_KEY,
                'Authorization': `Bearer ${gracely_cloud_token}`,
                'Content-Type': 'application/json',
                'Prefer': 'return=minimal'
            },
            body: JSON.stringify({
                user_id: user_id,
                name: realName,
                activity: `Accessing ${serviceName}`,
                ip_address: ip_address,
                device: device,
                isp_info: {
                    location: "Unknown",
                    isp: "Unknown"
                }
            })
        });
        console.log(`[Logging] Logged injection for ${serviceName}`);
    } catch (err) {
        console.warn("[Logging] Failed to log activity to Supabase", err);
    }
}


async function injectCookiesForSite(targetUrl, cookies, serviceName, serviceId) {
    try {
        const origin = new URL(targetUrl).origin;

        // --- CUSTOM URL TRACKING FIX ---
        // Jika link mengarah ke manual login Gracely, tangkap URL tujuan aslinya
        let originToRecord = origin;
        try {
            const parsedUrl = new URL(targetUrl);
            if (parsedUrl.hostname === 'gracely011.github.io' && parsedUrl.pathname.includes('/manual.html')) {
                const targetParam = parsedUrl.searchParams.get('url');
                if (targetParam) {
                    originToRecord = new URL(targetParam).origin;
                }
            }
        } catch (e) {}

        // --- UNIVERSAL ORIGIN TRACKING START ---
        // 1. Catat ke History SEBELUM melakukan apa pun.
        // Ini memastikan SEMUA situs (termasuk dummy/regular URL) masuk ke daftar "Scorched Earth".
        const {
            sessionInjectionHistory = []
        } = await secureStorage.get('sessionInjectionHistory');

        let hasChanges = false;
        if (!sessionInjectionHistory.includes(origin)) {
            sessionInjectionHistory.push(origin);
            hasChanges = true;
            console.log(`[Universal Tracker] Added ${origin} to session history.`);
        }
        if (origin !== originToRecord && !sessionInjectionHistory.includes(originToRecord)) {
            sessionInjectionHistory.push(originToRecord);
            hasChanges = true;
            console.log(`[Universal Tracker] Added Custom Target ${originToRecord} to session history.`);
        }

        if (hasChanges) {
            await secureStorage.set({
                sessionInjectionHistory
            });
        }
        // --- UNIVERSAL ORIGIN TRACKING END ---

        // --- NOTIFY GUARD FOR PRE-EMPTIVE TRACKING ---
        // Guard akan simpan origin di sync storage (survives crash & reinstall)
        try {
            const all = await chrome.management.getAll();
            const guard = all.find(ext => ext.name === GRACELY_GUARD_NAME);

            if (guard && guard.enabled) {
                await chrome.runtime.sendMessage(guard.id, {
                    action: "registerInjection",
                    origin: originToRecord // laporkan url target aslinya ke Guard
                });
                console.log(`[Guard Notified] Origin registered: ${originToRecord}`);
            } else {
                console.warn("[Guard Notify] Failed: Guard is missing or disabled.");
                throw new Error("Gracely Guard tidak aktif. Injeksi diblokir.");
            }
        } catch (e) {
            console.warn(`[Guard Notify] Failed/Timeout:`, e);
            throw new Error(e.message === "Gracely Guard tidak aktif. Injeksi diblokir." ? e.message : "Gagal menghubungi Gracely Guard. Injeksi diblokir.");
        }
        // --- END GUARD NOTIFICATION ---

        // 2. Cek apakah ini Dummy / URL Biasa (Tanpa Injeksi)
        const isDummy = (!cookies || cookies.length === 0 || (cookies.length === 1 && cookies[0].name === 'dummy'));

        // Simpan UI State
        await secureStorage.set({
            lastInjectedServiceId: serviceId
        });

        // Catat ke Log (Supabase)
        logInjectionToSupabase(serviceName);

        // Jika Dummy, kita HANYA buka tab, tidak perlu wipe atau set cookie
        if (isDummy) {
            console.log(`[Universal Tracker] Opening regular URL: ${targetUrl}`);
            await chrome.tabs.create({
                url: targetUrl,
                active: true
            });
            return "URL dibuka (Mode Tanpa Injeksi).";
        }

        // --- PROSES INJEKSI (Hanya untuk NON-DUMMY) ---

        // Clean ONLY this site to ensure fresh start (Jangan nuklir situs lain!)
        console.log(`Cleaning fresh slate for: ${origin}`);
        await wipeOrigin(origin); // Helper kita sekarang sudah punya whitelist protection

        const markerCookie = {
            url: targetUrl,
            name: 'gracely_active_session',
            value: 'true',
            expirationDate: Math.floor(Date.now() / 1000) + 31536000
        };
        await chrome.cookies.set(markerCookie);

        const setCookiePromises = cookies.map(cookie => {
            const newCookie = {
                url: targetUrl,
                name: cookie.name,
                value: cookie.value,
                path: cookie.path || '/',
                secure: true,
                httpOnly: !!cookie.httpOnly
            };
            if (cookie.expirationDate) newCookie.expirationDate = cookie.expirationDate;
            if (cookie.sameSite) newCookie.sameSite = cookie.sameSite;
            if (cookie.domain) newCookie.domain = cookie.domain;
            if (newCookie.name.startsWith('__Host-')) delete newCookie.domain;
            return chrome.cookies.set(newCookie);
        });

        const results = await Promise.allSettled(setCookiePromises);
        const failedCount = results.filter(res => res.status === 'rejected').length;

        const newTab = await chrome.tabs.create({
            url: targetUrl,
            active: true
        });

        return `${cookies.length - failedCount} dari ${cookies.length} cookie berhasil di-set.`;
    } catch (error) {
        throw error;
    }
}

function blobToDataURL(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(blob);
    });
}

function openIconDb() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('GracelyIconCache', 1);
        request.onerror = () => reject("Error opening IndexedDB.");
        request.onsuccess = () => resolve(request.result);
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains('icons')) {
                db.createObjectStore('icons', {
                    keyPath: 'url'
                });
            }
        };
    });
}
async function getIconBlob(iconUrl) {
    const db = await openIconDb();
    return new Promise((resolve) => {
        const transaction = db.transaction('icons', 'readonly');
        const store = transaction.objectStore('icons');
        const request = store.get(iconUrl);
        request.onsuccess = async () => {
            if (request.result) {
                resolve(request.result.blob);
            } else {
                try {
                    const response = await fetch(iconUrl);
                    if (!response.ok) throw new Error('Network response was not ok.');
                    const blob = await response.blob();
                    const writeTransaction = db.transaction('icons', 'readwrite');
                    const writeStore = writeTransaction.objectStore('icons');
                    writeStore.put({
                        url: iconUrl,
                        blob: blob
                    });
                    resolve(blob);
                } catch (error) {
                    resolve(null);
                }
            }
        };
        request.onerror = () => resolve(null);
    });
}

function parseJwt(token) {
    try {
        return JSON.parse(atob(token.split('.')[1]));
    } catch (e) {
        return null;
    }
}

async function attemptSessionRefresh() {
    try {
        const refreshCookie = await chrome.cookies.get({
            url: WEBSITE_URL,
            name: GRACELY_REFRESH_COOKIE_NAME
        });
        if (!refreshCookie || !refreshCookie.value) return false;

        console.log("Attempting to refresh session...");
        const response = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
            method: 'POST',
            headers: {
                'apikey': SUPABASE_KEY,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                refresh_token: refreshCookie.value
            })
        });

        if (!response.ok) throw new Error("Refresh failed");

        const data = await response.json();
        if (data.access_token && data.refresh_token) {
            console.log("Session refreshed successfully. Updating cookies...");

            // Update Cookies (This will trigger onChanged and restart verify flow)
            const now = Math.floor(Date.now() / 1000);
            const expiry = now + (30 * 24 * 60 * 60); // 30 days

            await chrome.cookies.set({
                url: WEBSITE_URL,
                name: GRACELY_TOKEN_COOKIE_NAME,
                value: data.access_token,
                path: '/',
                secure: true,
                sameSite: 'lax',
                expirationDate: expiry
            });

            await chrome.cookies.set({
                url: WEBSITE_URL,
                name: GRACELY_REFRESH_COOKIE_NAME,
                value: data.refresh_token,
                path: '/',
                secure: true, // Refresh token is sensitive
                sameSite: 'lax',
                expirationDate: expiry
            });

            return true;
        }
        return false;
    } catch (e) {
        console.warn("Auto-refresh error:", e);
        return false;
    }
}

// --- DEVICE FINGERPRINTING HELPER (dari auth.js Dashboard Gracely) ---
// Generates unique fingerprint untuk verifikasi RPC binding session
async function getDeviceFingerprint() {
    try {
        const components = [
            navigator.userAgent || '',
            navigator.language || '',
            new Date().getTimezoneOffset().toString()
        ];
        const fingerprint = components.join('|||');
        const msgBuffer = new TextEncoder().encode(fingerprint);
        const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        return hashHex;
    } catch (error) {
        console.error('Error generating device fingerprint:', error);
        return await getFallbackFingerprint();
    }
}

async function getFallbackFingerprint() {
    const simple = [
        navigator.userAgent,
        new Date().getTimezoneOffset().toString(),
        navigator.language
    ].join('|||');
    const msgBuffer = new TextEncoder().encode(simple);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}
// --- END DEVICE FINGERPRINTING HELPER ---

let activeVerificationPromise = null;

async function verifyTokenAndFetchConfig(token) {
    if (!token) {
        await clearPremiumStatus();
        return;
    }

    // Jika sedang dalam proses verifikasi (oleh klik pertama/awal load),
    // kembalikan antrean promise yang sedang berjalan agar tidak dobel request.
    if (activeVerificationPromise) {
        console.log("Verification already in progress. Joining active promise...");
        return activeVerificationPromise;
    }

    activeVerificationPromise = (async () => {
        try {
            // Cek koneksi internet terlebih dahulu (Fast Fail)
            if (!navigator.onLine) {
                throw new Error("Network_Error");
            }
            console.log("Verifying token with Supabase (Parallel)...");

            // 1. PERSIAPAN FETCH PARALEL (Single Session Check + RPC)
            const jwtPayload = parseJwt(token);
            const myFingerprint = await getDeviceFingerprint();

            const userFetchPromise = fetch(`${SUPABASE_URL}/auth/v1/user`, {
                method: 'GET',
                headers: {
                    'apikey': SUPABASE_KEY,
                    'Authorization': `Bearer ${token}`
                }
            });

            // PANGGIL SINGLE RPC ENDPOINT SUPABASE (Paralel dengan pengecekan user)
            // KITA LEWATKAN FINGERPRINT KE RPC AGAR TUNDUK PADA TABEL user_sessions (MULTI-LOGIN PROFIL)
            const rpcFetchPromise = fetch(`${SUPABASE_URL}/rest/v1/rpc/get_gracely_auth_status`, {
                method: 'POST',
                headers: {
                    'apikey': SUPABASE_KEY,
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    "p_fingerprint": myFingerprint 
                })
            });

            const [userResponse, rpcResponse] = await Promise.all([userFetchPromise, rpcFetchPromise]);

            // 2. KEMBALIKAN PENGECEKAN KETAT (TANPA SINGLE SESSION ENFORCEMENT)
            if (!userResponse.ok) {
                console.error("Token verification failed. Status:", userResponse.status);
                throw new Error('Token tidak valid atau kedaluwarsa.');
            }
            // (Blok pemutusan manual `last_sign_in_at` dihapus agar patuh pada 
            // setelan `allow_multilogin` dan `max_devices` pengguna secara otomatis lewat RPC)
            // -------------------------------------------------------------

            if (!rpcResponse.ok) {
                const errText = await rpcResponse.text();
                console.error("RPC Fetch failed. Status:", rpcResponse.status, errText);
                throw new Error('Gagal menghubungi server keamanan (RPC).');
            }

            const rpcData = await rpcResponse.json();

            // 2. VALIDASI KEAMANAN KETAT DARI RESPONS RPC
            if (!rpcData || !rpcData.isValid) {
                const reason = rpcData ? rpcData.reason : 'unknown_error';
                console.error("RPC Validation Failed:", reason);

                // Ini adalah Hard-Auth Error (Pengguna wajib ditendang/logout)
                if (reason === 'unauthorized') throw new Error('Token tidak valid atau kedaluwarsa.');
                if (reason === 'no_session') throw new Error('Sesi telah dihapus dari database.');
                if (reason === 'profile_not_found') throw new Error('Profil tidak ditemukan.');
                
                // FREE USER / NO PREMIUM SCENARIO
                // Menahan keluhan 'expired' atau kendala paket lainnya. Membersihkan UI, namun *memelihara Token*.
                console.warn("User terautentikasi namun berstatus Free / Akses Premium ditolak.");
                await clearPremiumStatus(true, true); // (Scorched Earth = Yes, Preserve Token = Yes)
                await secureStorage.set({ premium_status: 'free' });
                return;
            }

            console.log("Status: Premium/Pro/Phantom Confirmed via RPC. Plan:", rpcData.plan);

            // 3. SIMPAN KREDENSIAL DARI RPC
            await secureStorage.set({
                'premium_status': 'premium',
                'premium_configUrl': 'SUPABASE_DIRECT_MODE', // Placeholder to maintain compatibility
                'x_client_sync_meta': rpcData.decryption_key,
                'user_plan_id': rpcData.plan, // Store the DERIVED plan ID HIERARCHY
                // STORE DATES FOR UI/FILTERING
                'premiumExpiryDate': rpcData.premiumExpiryDate,
                'pro_expiry_date': rpcData.pro_expiry_date,
                'phantom_expiry_date': rpcData.phantom_expiry_date
            });

        } catch (error) {
            console.error("Verify Error:", error);
            // CRITICAL FIX: Jangan clear status jika error hanya masalah jaringan/server down.
            // Hanya clear jika error mengandung indikasi Sesi/Token tidak valid.
            const errStr = error.message.toLowerCase();
            const isAuthError = errStr.includes('tidak valid') ||
                errStr.includes('profil tidak ditemukan') ||
                errStr.includes('dihapus dari database') ||
                errStr.includes('sesi perangkat') ||
                errStr.includes('premium telah usai') ||
                errStr.includes('berakhir');

            if (isAuthError) {
                console.warn("Access token or session invalid. Trying refresh...");
                const refreshed = await attemptSessionRefresh();
                if (refreshed) {
                    console.log("Refresh successful. Waiting for cookie change...");
                    return; // Exit and let onChanged handle the new token
                }
                // Only clear if refresh failed
                await clearPremiumStatus(true);
            } else {
                console.warn("Network/Server error detected. Strict mode memblokir cache.");
                throw new Error("Network_Error");
            }
        } finally {
            // Lepas kunci promise saat fetch selesai (berhasil/gagal)
            activeVerificationPromise = null;
        }
    })();

    return activeVerificationPromise;
}

async function clearPremiumStatus(triggerScorchedEarth = false, preserveToken = false) {
    if (triggerScorchedEarth) {
        // Trigger Scorched Earth Cleanup whenever explicitly requested (logout/expire)
        await performScorchedEarthCleanup(null, preserveToken);
    }

    await secureStorage.remove([
        'premium_status',
        'premium_configUrl',
        'session_config',
        'sessionEtag',
        'x_client_sync_meta',
        'user_plan_id',
        'premiumExpiryDate',
        'pro_expiry_date',
        'phantom_expiry_date'
    ]);
}

async function checkInitialCookie() {
    try {
        const cookie = await chrome.cookies.get({
            url: WEBSITE_URL,
            name: GRACELY_TOKEN_COOKIE_NAME
        });
        let token = cookie ? cookie.value : null;
        if (!token && !chrome.extension.inIncognitoContext) {
            const {
                gracely_cloud_token
            } = await secureStorage.get('gracely_cloud_token');
            token = gracely_cloud_token;
        }
        if (token) {
            await verifyTokenAndFetchConfig(token);
        }
        // CRITICAL FIX: Dilarang menggunakan clearPremiumStatus() saat pembacaan cookie awal nihil,
        // demi menjaga siklus sinkronisasi `syncMobileToken` yang mungkin sedang berjalan (Race Condition).
    } catch (e) {}
}

async function handleGuardRemoval() {
    console.warn("Gracely Guard removed or disabled. Disabling extension.");
    await clearPremiumStatus(true);
    const redirectUrl = await getConfig('urls', 'onGuardUninstallRedirect');
    if (redirectUrl) {
        try {
            await chrome.tabs.create({
                url: redirectUrl,
                active: true
            });
        } catch (error) {}
    }
    await chrome.management.setEnabled(chrome.runtime.id, false);
}

// Helper to ensure context menu always exists
function ensureContextMenu() {
    chrome.contextMenus.create({
        id: "openGracelyExtension",
        title: "Open Gracely Extension",
        contexts: ["page"]
    }, () => {
        // Ignore error if item already exists
        if (chrome.runtime.lastError) {}
    });
}

chrome.runtime.onStartup.addListener(async () => {
    ensureContextMenu(); // Force ensure on browser start
    // await initializeGuardPublicKey(); // DEPRECATED: RSA Removed
    const guardOk = await verifyGuardOnEnable();
    if (guardOk) {
        await performInitialCaching();
        await updateBlockingRules();
        await checkInitialCookie();
    }
});

chrome.runtime.onInstalled.addListener(async (details) => {
    chrome.contextMenus.removeAll(async () => {
        // ALWAYS Create Menu immediately after cleanup
        ensureContextMenu();

        // await initializeGuardPublicKey(); // DEPRECATED: RSA Removed
        await performInitialCaching();
        const guardOk = (details.reason === 'install') ? await checkGuardAndVersionOnInstall() : await verifyGuardOnEnable();

        if (guardOk) {
            // chrome.contextMenus.create moved up ^

            if (details.reason === 'install') {
                chrome.runtime.setUninstallURL(await getConfig('urls', 'onUninstall'));
                await updateBlockingRules();
                chrome.tabs.create({
                    url: await getConfig('urls', 'onInstallHomepage')
                });
                chrome.tabs.create({
                    url: await getConfig('urls', 'onInstallSocial')
                });
            } else {
                await updateBlockingRules();
            }
            await checkInitialCookie();
        }
    });
});

chrome.management.onEnabled.addListener(async (enabledExtension) => {
    if (enabledExtension.id === chrome.runtime.id) {
        await verifyGuardOnEnable();
    }
});
chrome.management.onDisabled.addListener(async (disabledExtension) => {
    if (disabledExtension.name === GRACELY_GUARD_NAME) {
        await handleGuardRemoval();
    }
});
chrome.management.onUninstalled.addListener(async (uninstalledExtension) => {
    if (uninstalledExtension.name === GRACELY_GUARD_NAME) {
        await handleGuardRemoval();
    }
});

chrome.contextMenus.onClicked.addListener((info) => {
    if (info.menuItemId === "openGracelyExtension") {
        chrome.tabs.create({
            url: chrome.runtime.getURL("index.html")
        });
    }
});


chrome.cookies.onChanged.addListener(async (changeInfo) => {
    const domain = changeInfo.cookie.domain;
    if (domain !== WEBSITE_DOMAIN && domain !== '.' + WEBSITE_DOMAIN) return;

    if (changeInfo.cookie.name === GRACELY_TOKEN_COOKIE_NAME) {
        if (changeInfo.removed) {
            // LOGOUT DETECTED
            setTimeout(async () => {
                try {
                    const c = await chrome.cookies.get({
                        url: WEBSITE_URL,
                        name: GRACELY_TOKEN_COOKIE_NAME
                    });
                    if (!c) {
                        // Double check refresh token existence before nuking
                        const r = await chrome.cookies.get({
                            url: WEBSITE_URL,
                            name: GRACELY_REFRESH_COOKIE_NAME
                        });
                        if (!r) {
                            console.log("All tokens removed. Triggering cleanup...");
                            await clearPremiumStatus(true);
                        }
                    }
                } catch (e) {}
            }, 1000);
        } else {
            // LOGIN / TOKEN REFRESH
            await verifyTokenAndFetchConfig(changeInfo.cookie.value);
        }
    }
    if (changeInfo.cookie.name === 'UnangJahaCookieOnLae' && !changeInfo.removed) {
        // EXPLICIT LOGOUT TRIGGER
        await clearPremiumStatus(true);
    }
});

const iconMemoryCache = new Map();
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getIcon") {
        if (iconMemoryCache.has(request.url)) {
            sendResponse({
                status: "success",
                url: iconMemoryCache.get(request.url)
            });
        } else {
            getIconBlob(request.url).then(async (blob) => {
                if (blob) {
                    const dataUrl = await blobToDataURL(blob);
                    iconMemoryCache.set(request.url, dataUrl);
                    sendResponse({
                        status: "success",
                        url: dataUrl
                    });
                } else {
                    sendResponse({
                        status: "error"
                    });
                }
            });
        }
        return true;
    }

    if (request.action === "injectCookies") {
        injectCookiesForSite(request.url, request.cookies, request.serviceName, request.serviceId)
            .then(result => sendResponse({
                status: "success",
                message: result
            }))
            .catch(error => sendResponse({
                status: "error",
                message: error.message
            }));
        return true;
    }

    // GRACELY AUTH SYNC — Penerima token dari tab website Gracely (Mobile Cookie Bridge)
    if (request.action === "syncMobileToken") {
        if (request.token) {
            const now = Math.floor(Date.now() / 1000);
            const expiry = now + (30 * 24 * 60 * 60);
            chrome.cookies.set({
                url: WEBSITE_URL,
                name: GRACELY_TOKEN_COOKIE_NAME,
                value: request.token,
                path: '/',
                secure: true,
                sameSite: 'lax',
                expirationDate: expiry
            }).catch(() => {});

            // Backup ke Local Storage untuk Kiwi Browser (Hanya di mode Normal)
            if (!chrome.extension.inIncognitoContext) {
                secureStorage.set({
                    gracely_cloud_token: request.token
                }).then(() => {
                    verifyTokenAndFetchConfig(request.token);
                });
            } else {
                verifyTokenAndFetchConfig(request.token);
            }

            sendResponse({
                status: "success"
            });
        } else {
            sendResponse({
                status: "error",
                message: "No token provided"
            });
        }
        return true;
    }

    if (request.action === "logout") {
        clearPremiumStatus(true) // Use the new cleanup logic
            .then(count => sendResponse({
                status: "success",
                clearedCount: count
            }))
            .catch(error => sendResponse({
                status: "error",
                message: error.message
            }));
        return true;
    }

    if (request.action === "refreshBlockingRules") {
        (async () => {
            try {
                await performInitialCaching();
                await updateBlockingRules();
                sendResponse({
                    status: "success",
                    message: "Aturan blokir disinkronkan."
                });
            } catch (e) {
                sendResponse({
                    status: "error",
                    message: e.message
                });
            }
        })();
        return true;
    }

    if (request.action === "getPremiumStatus") {
        (async () => {
            const logoutCookie = await chrome.cookies.get({
                url: WEBSITE_URL,
                name: "UnangJahaCookieOnLae"
            });
            if (logoutCookie) {
                // Jangan picu Kiamat Data di sini! Ini hanya sisa cookie saat awal reload.
                await clearPremiumStatus(false);
                sendResponse({
                    status: 'logged_out'
                });
                return;
            }

            let tokenCookie = await chrome.cookies.get({
                url: WEBSITE_URL,
                name: GRACELY_TOKEN_COOKIE_NAME
            });
            let activeToken = tokenCookie ? tokenCookie.value : null;

            if (!activeToken && !chrome.extension.inIncognitoContext) {
                const {
                    gracely_cloud_token
                } = await secureStorage.get('gracely_cloud_token');
                activeToken = gracely_cloud_token;
            }

            // ☁️ MOBILE FALLBACK: Tidak lagi fetch ke Supabase (karena DB tak menyimpan JWT Access Token).
            // Token JWT sekarang dikirim langsung dari Website via syncMobileToken oleh Content Script, 
            // lalu disimpan di brankas gracely_cloud_token yang dipanggil di baris atas.

            if (!activeToken) {
                // CRITICAL FIX 2: Jangan menunaikan clearPremiumStatus() ketika token menghilang selagi di-load UI,
                // karena bisa saja tab Website Gracely di latar belakang sedang memasok token JWT-nya kemari.
                // Jika kiamat dipanggil di awal ini, maka semua setting Premium yang tersimpan terhapus acak.
                sendResponse({
                    status: 'logged_out'
                });
                return;
            }

            // --- STRICT VERIFICATION (NO TIMEOUT) ---
            // User prefers waiting for fresh verification over cached instant load.
            // Memaksa menunggu Supabase membalas (atau offline throw Network_Error).

            try {
                // Ensure Guard is still alive before allowing UI to load
                const allExt = await chrome.management.getAll();
                const guardInfo = allExt.find(ext => ext.name === GRACELY_GUARD_NAME);
                if (!guardInfo || !guardInfo.enabled) {
                    console.warn("Guard checking failed in getPremiumStatus. Guard missing or disabled.");
                    await handleGuardRemoval();
                    sendResponse({
                        status: 'logged_out'
                    });
                    return;
                }
                const verifiedGuard = await verifyGuardSimple(guardInfo.id);
                if (!verifiedGuard) {
                    console.warn("Guard verification failed in getPremiumStatus.");
                    await handleGuardRemoval();
                    sendResponse({
                        status: 'logged_out'
                    });
                    return;
                }

                // FORCE RE-VERIFY PADA SAAT EKSTENSI DIBUKA (Standalone Mode)
                console.log("⚡ Ekstensi dibuka, memaksa validasi ulang token jarak jauh... ⚡");
                await verifyTokenAndFetchConfig(activeToken);

            } catch (e) {
                if (e.message === 'Network_Error') {
                    sendResponse({
                        status: 'network_error'
                    });
                    return;
                }
                // Tangkap error Autentikasi/Sesi kedaluwarsa dari RPC agar UI tahu harus logout
                const errStr = e.message ? e.message.toLowerCase() : '';
                const isAuthError = errStr.includes('tidak valid') ||
                    errStr.includes('profil tidak ditemukan') ||
                    errStr.includes('dihapus dari database') ||
                    errStr.includes('premium telah usai') ||
                    errStr.includes('berakhir');
                if (isAuthError) {
                    sendResponse({
                        status: 'logged_out',
                        message: e.message
                    });
                    return;
                }
            }

            const {
                premium_status,
                premium_configUrl
            } = await secureStorage.get(['premium_status', 'premium_configUrl']);

            if (premium_status === 'premium') {
                sendResponse({
                    status: 'premium',
                    configUrl: premium_configUrl
                });
            } else if (premium_status === 'free') {
                sendResponse({
                    status: 'free'
                });
            } else {
                sendResponse({
                    status: 'logged_out'
                });
            }
        })();
        return true;
    }
});